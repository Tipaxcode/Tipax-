-- ===== ۱) کلید روشن/خاموش تیپاکس (رمز مدیر: sobhancodm1) =====
-- ============================================================
--  راه‌اندازی کلید روشن/خاموش (Supabase → SQL Editor → Run)
--  ۱) رمز مدیر: sobhancodm1 (برای عوض کردنش، همین عبارت را در خط insert عوض کن).
--  ۲) یک‌بار اجرا کن. دوباره اجرا کردنش بی‌خطر است.
-- ============================================================

-- جدول وضعیت (id=1: فعال یا غیرفعال)
create table if not exists public.tipax_app_status (
  id int primary key,
  active boolean not null default true,
  updated_at timestamptz not null default now()
);
-- اگر جدول از قبل بدون این ستون ساخته شده بود، اضافه‌اش می‌کند
alter table public.tipax_app_status
  add column if not exists updated_at timestamptz not null default now();

insert into public.tipax_app_status (id, active) values (1, true)
  on conflict (id) do nothing;

alter table public.tipax_app_status enable row level security;
drop policy if exists "read status" on public.tipax_app_status;
create policy "read status" on public.tipax_app_status
  for select to anon, authenticated using (true);      -- همه فقط می‌توانند «بخوانند»

-- رمز مدیر (فقط هش ذخیره می‌شود؛ جدول هیچ policy ندارد پس از بیرون قابل خواندن نیست)
create table if not exists public.tipax_admin (
  id int primary key default 1,
  pw_hash text not null
);
alter table public.tipax_admin enable row level security;
insert into public.tipax_admin (id, pw_hash)
  values (1, encode(sha256(convert_to('sobhancodm1', 'UTF8')), 'hex'))
  on conflict (id) do update set pw_hash = excluded.pw_hash;

-- تابع تغییر وضعیت: فقط با رمز درست
create or replace function public.set_tipax_status(pw text, val boolean)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if not exists (
    select 1 from public.tipax_admin
    where id = 1
      and pw_hash = encode(sha256(convert_to(coalesce(pw, ''), 'UTF8')), 'hex')
  ) then
    raise exception 'wrong password';
  end if;
  update public.tipax_app_status set active = val, updated_at = now() where id = 1;
end;
$$;

revoke all on function public.set_tipax_status(text, boolean) from public;
grant execute on function public.set_tipax_status(text, boolean) to anon, authenticated;

-- ===== ۲) برنامه‌ی PS5 =====
-- ===== جدول‌ها =====
create table if not exists public.shop_prices (shop text not null, game text not null, price bigint not null check (price > 0 and price <= 1000000000), primary key (shop, game));
create table if not exists public.shop_info (shop text primary key, info jsonb not null default '{}'::jsonb);

alter table public.shop_prices enable row level security;
alter table public.shop_info enable row level security;
revoke all on public.shop_prices from anon, authenticated;
revoke all on public.shop_info from anon, authenticated;

-- ===== قیمت‌ها =====
create or replace function public.shop_list() returns jsonb language sql security definer set search_path = public as $$
  select coalesce(jsonb_agg(distinct shop), '[]'::jsonb) from public.shop_prices;
$$;

create or replace function public.shop_prices_get(p_shop text) returns jsonb language sql security definer set search_path = public as $$
  select coalesce(jsonb_object_agg(game, price), '{}'::jsonb) from public.shop_prices
  where lower(regexp_replace(shop, '\s', '', 'g')) = lower(regexp_replace(coalesce(p_shop, ''), '\s', '', 'g'));
$$;

create or replace function public.shop_prices_set(p_code text, p_shop text, p_prices jsonb) returns void language plpgsql security definer set search_path = public as $$
begin
  perform public.admin_list(p_code);
  if coalesce(trim(p_shop), '') = '' then raise exception 'shop required'; end if;
  delete from public.shop_prices where lower(regexp_replace(shop, '\s', '', 'g')) = lower(regexp_replace(p_shop, '\s', '', 'g'));
  insert into public.shop_prices (shop, game, price)
  select p_shop, key, value::bigint from jsonb_each_text(coalesce(p_prices, '{}'::jsonb))
  where value ~ '^\d+$' and value::numeric > 0 and value::numeric <= 1000000000;
end;
$$;

-- ===== اطلاعات و آدرس شاپ =====
create or replace function public.shop_info_all() returns jsonb language sql security definer set search_path = public as $$
  select coalesce(jsonb_object_agg(shop, info), '{}'::jsonb) from public.shop_info;
$$;

create or replace function public.shop_info_set(p_code text, p_shop text, p_info jsonb) returns void language plpgsql security definer set search_path = public as $$
begin
  perform public.admin_list(p_code);
  if coalesce(trim(p_shop), '') = '' then raise exception 'shop required'; end if;
  delete from public.shop_info where lower(regexp_replace(shop, '\s', '', 'g')) = lower(regexp_replace(p_shop, '\s', '', 'g'));
  insert into public.shop_info (shop, info) values (p_shop, jsonb_build_object(
    'addr',  left(coalesce(p_info->>'addr',  ''), 300),
    'tel',   left(coalesce(p_info->>'tel',   ''), 40),
    'hours', left(coalesce(p_info->>'hours', ''), 60),
    'note',  left(coalesce(p_info->>'note',  ''), 200)));
end;
$$;

-- ===== دسترسی‌ها =====
grant execute on function public.shop_list() to anon, authenticated;
grant execute on function public.shop_prices_get(text) to anon, authenticated;
grant execute on function public.shop_prices_set(text, text, jsonb) to anon, authenticated;
grant execute on function public.shop_info_all() to anon, authenticated;
grant execute on function public.shop_info_set(text, text, jsonb) to anon, authenticated;

-- ===== بازی‌های اختصاصی هر شاپ (افزودن بازی + غیرفعال کردن بازی) =====
create table if not exists public.shop_games (shop text primary key, cfg jsonb not null default '{}'::jsonb);
alter table public.shop_games enable row level security;
revoke all on public.shop_games from anon, authenticated;

create or replace function public.shop_games_all() returns jsonb language sql security definer set search_path = public as $$
  select coalesce(jsonb_object_agg(shop, cfg), '{}'::jsonb) from public.shop_games;
$$;

create or replace function public.shop_games_set(p_code text, p_shop text, p_cfg jsonb) returns void language plpgsql security definer set search_path = public as $$
declare v_extra jsonb; v_hidden jsonb;
begin
  perform public.admin_list(p_code);
  if coalesce(trim(p_shop), '') = '' then raise exception 'shop required'; end if;
  select coalesce(jsonb_agg(e), '[]'::jsonb) into v_extra from (
    select e from jsonb_array_elements(case when jsonb_typeof(p_cfg->'extra') = 'array' then p_cfg->'extra' else '[]'::jsonb end) e
    where jsonb_typeof(e) = 'array' and jsonb_array_length(e) >= 3
      and jsonb_typeof(e->0) = 'string' and length(e->>0) between 1 and 60
      and (e->>1) ~ '^\d+(\.\d+)?$' and (e->>1)::numeric > 0 and (e->>1)::numeric <= 2000
      and (e->>2) in ('act','rpg','shoot','horror','sport','fight','fam')
    limit 300) s;
  select coalesce(jsonb_agg(h), '[]'::jsonb) into v_hidden from (
    select h from jsonb_array_elements(case when jsonb_typeof(p_cfg->'hidden') = 'array' then p_cfg->'hidden' else '[]'::jsonb end) h
    where jsonb_typeof(h) = 'string' and length(h #>> '{}') between 1 and 60
    limit 1000) s;
  delete from public.shop_games where lower(regexp_replace(shop, '\s', '', 'g')) = lower(regexp_replace(p_shop, '\s', '', 'g'));
  insert into public.shop_games (shop, cfg) values (p_shop, jsonb_build_object('extra', v_extra, 'hidden', v_hidden));
end;
$$;

grant execute on function public.shop_games_all() to anon, authenticated;
grant execute on function public.shop_games_set(text, text, jsonb) to anon, authenticated;

-- ===== لینک‌های دانلود بخش کامپیوتر (برای همه دیده می‌شود) =====
create table if not exists public.pc_links (game text primary key, links jsonb not null default '[]'::jsonb);
alter table public.pc_links enable row level security;
revoke all on public.pc_links from anon, authenticated;

create or replace function public.pc_links_all() returns jsonb language sql security definer set search_path = public as $$
  select coalesce(jsonb_object_agg(game, links), '{}'::jsonb) from public.pc_links;
$$;

create or replace function public.pc_links_set(p_code text, p_links jsonb) returns void language plpgsql security definer set search_path = public as $$
declare k text; v jsonb;
begin
  perform public.admin_list(p_code);
  if jsonb_typeof(p_links) <> 'object' then raise exception 'bad links'; end if;
  for k, v in select key, value from jsonb_each(p_links) loop
    if length(k) < 1 or length(k) > 80 then continue; end if;
    if jsonb_typeof(v) <> 'array' or jsonb_array_length(v) = 0 then
      delete from public.pc_links where game = k;
    else
      insert into public.pc_links (game, links)
      select k, coalesce(jsonb_agg(e), '[]'::jsonb) from (
        select e from jsonb_array_elements(v) e
        where jsonb_typeof(e) = 'string' and (e #>> '{}') ~ '^https://[^\s"''<>]+$' and length(e #>> '{}') < 600
        limit 100) s
      on conflict (game) do update set links = excluded.links;
    end if;
  end loop;
end;
$$;

grant execute on function public.pc_links_all() to anon, authenticated;
grant execute on function public.pc_links_set(text, jsonb) to anon, authenticated;

-- ===== عکس پروفایل کاربرها (برای نمایش در بخش ادمین) =====
create table if not exists public.player_avatars (pid text primary key, name_key text not null default '', av text not null check (length(av) <= 60000), updated_at timestamptz not null default now());
alter table public.player_avatars enable row level security;
revoke all on public.player_avatars from anon, authenticated;

create or replace function public.set_avatar(p_id text, p_name text, p_av text) returns void language plpgsql security definer set search_path = public as $$
begin
  if p_id is null or length(p_id) < 1 or length(p_id) > 80 then raise exception 'bad id'; end if;
  if p_av is null or p_av = '' then
    delete from public.player_avatars where pid = p_id;
    return;
  end if;
  if length(p_av) > 60000 or p_av !~ '^data:image/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$' then raise exception 'bad avatar'; end if;
  insert into public.player_avatars (pid, name_key, av, updated_at)
  values (p_id, lower(btrim(coalesce(p_name, ''))), p_av, now())
  on conflict (pid) do update set name_key = excluded.name_key, av = excluded.av, updated_at = now();
end;
$$;

create or replace function public.avatars_all(p_code text) returns jsonb language plpgsql security definer set search_path = public as $$
begin
  begin
    perform public.admin_list(p_code);
  exception when others then
    perform public.root_list(p_code);
  end;
  return coalesce((select jsonb_agg(jsonb_build_object('pid', pid, 'name', name_key, 'av', av)) from public.player_avatars), '[]'::jsonb);
end;
$$;

grant execute on function public.set_avatar(text, text, text) to anon, authenticated;
grant execute on function public.avatars_all(text) to anon, authenticated;

notify pgrst, 'reload schema';

-- ===== ۳) تنظیمات راه‌دور (رنگ، متن، تأخیر، روش ثبت) =====
-- ============================================================
--  تنظیمات راه‌دور (رنگ، متن، تأخیر، روش ثبت) - بعد از supabase_setup.sql یک‌بار اجرا کن
--  دوباره اجرا کردنش بی‌خطر است. نسخه‌های قدیمی برنامه فقط ستون active را می‌خوانند و خراب نمی‌شوند.
-- ============================================================
alter table public.tipax_app_status
  add column if not exists config jsonb not null default '{}'::jsonb;

create or replace function public.set_tipax_config(pw text, cfg jsonb)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if not exists (
    select 1 from public.tipax_admin
    where id = 1
      and pw_hash = encode(sha256(convert_to(coalesce(pw, ''), 'UTF8')), 'hex')
  ) then
    raise exception 'wrong password';
  end if;
  update public.tipax_app_status
     set config = coalesce(cfg, '{}'::jsonb), updated_at = now()
   where id = 1;
end;
$$;

revoke all on function public.set_tipax_config(text, jsonb) from public;
grant execute on function public.set_tipax_config(text, jsonb) to anon, authenticated;

-- بعد از ساخت ستون، کش API سوپابیس را تازه می‌کند (بدون این، گاهی ستون جدید دیده نمی‌شود)
notify pgrst, 'reload schema';

-- ===== ۴) کد اشتراک ۴ رقمی =====
-- ============================================================
--  کد اشتراک ۴ رقمی (جایگزین رمز ورود ثابت) - Supabase → SQL Editor → Run
--  بعد از supabase_setup.sql یک‌بار اجرا کن. دوباره اجرا کردنش بی‌خطر است.
--  مدیر از پنل برای هر نفر یک کد می‌سازد؛ هر کد فقط روی یک گوشی فعال می‌شود.
-- ============================================================
drop function if exists public.tipax_ping(text, text, text, text);
drop function if exists public.tipax_users_list(text);
drop function if exists public.tipax_user_ban(text, text, boolean);
drop function if exists public.tipax_user_delete(text, text);
drop table if exists public.tipax_users;

create table if not exists public.tipax_codes (
  code         text primary key check (code ~ '^[0-9]{4}$'),
  label        text not null default '',          -- یادداشت مدیر (مثلاً اسم صاحب کد)
  device_id    text,                              -- گوشی‌ای که کد روی آن فعال شده
  model        text not null default '',
  app_ver      text not null default '',
  banned       boolean not null default false,
  created_at   timestamptz not null default now(),
  activated_at timestamptz,
  last_seen    timestamptz
);
alter table public.tipax_codes enable row level security;
revoke all on public.tipax_codes from anon, authenticated;

-- شمارنده‌ی تلاش‌های اشتباه هر گوشی (جلوی حدس زدن کد)
create table if not exists public.tipax_fails (
  id   text primary key,
  n    int not null default 0,
  last timestamptz not null default now()
);
alter table public.tipax_fails enable row level security;
revoke all on public.tipax_fails from anon, authenticated;

create or replace function public.tipax_admin_ok(pw text) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not exists (
    select 1 from public.tipax_admin
    where id = 1 and pw_hash = encode(sha256(convert_to(coalesce(pw, ''), 'UTF8')), 'hex')
  ) then
    raise exception 'wrong password';
  end if;
end;
$$;
revoke all on function public.tipax_admin_ok(text) from public;

-- ورود با کد: ok | invalid | used | banned | locked
create or replace function public.tipax_activate(p_code text, p_id text, p_model text, p_ver text)
returns text
language plpgsql security definer set search_path = public as $$
declare r public.tipax_codes; f public.tipax_fails; v_found boolean;
begin
  if p_id is null or length(p_id) < 1 or length(p_id) > 80 then raise exception 'bad id'; end if;
  select * into f from public.tipax_fails where id = p_id;
  if found and f.n >= 8 and f.last > now() - interval '15 minutes' then return 'locked'; end if;

  select * into r from public.tipax_codes where code = btrim(coalesce(p_code, '')) for update;
  v_found := found;
  if not v_found or (r.device_id is not null and r.device_id <> p_id) then
    insert into public.tipax_fails (id, n, last) values (p_id, 1, now())
    on conflict (id) do update set
      n = case when public.tipax_fails.last < now() - interval '15 minutes' then 1 else public.tipax_fails.n + 1 end,
      last = now();
    return case when v_found then 'used' else 'invalid' end;
  end if;
  if r.banned then return 'banned'; end if;

  update public.tipax_codes set
    device_id = p_id,
    model = left(coalesce(p_model, ''), 60),
    app_ver = left(coalesce(p_ver, ''), 20),
    activated_at = coalesce(activated_at, now()),
    last_seen = now()
  where code = r.code;
  delete from public.tipax_fails where id = p_id;
  return 'ok';
end;
$$;

-- هر چند ثانیه از گوشی: ok | banned | invalid (کد حذف/آزاد شده) | used (روی گوشی دیگری رفته)
create or replace function public.tipax_ping(p_code text, p_id text, p_model text, p_ver text)
returns text
language plpgsql security definer set search_path = public as $$
declare r public.tipax_codes;
begin
  select * into r from public.tipax_codes where code = btrim(coalesce(p_code, ''));
  if not found or r.device_id is null then return 'invalid'; end if;
  if r.device_id <> coalesce(p_id, '') then return 'used'; end if;
  update public.tipax_codes set
    model = case when coalesce(p_model, '') <> '' then left(p_model, 60) else model end,
    app_ver = case when coalesce(p_ver, '') <> '' then left(p_ver, 20) else app_ver end,
    last_seen = now()
  where code = r.code;
  return case when r.banned then 'banned' else 'ok' end;
end;
$$;

-- ساخت کد رندم ۴ رقمی جدید (فقط مدیر)
create or replace function public.tipax_code_create(pw text, p_label text) returns text
language plpgsql security definer set search_path = public as $$
declare c text; i int := 0;
begin
  perform public.tipax_admin_ok(pw);
  loop
    c := (1000 + floor(random() * 9000))::int::text;
    begin
      insert into public.tipax_codes (code, label) values (c, left(btrim(coalesce(p_label, '')), 60));
      return c;
    exception when unique_violation then
      i := i + 1;
      if i > 60 then raise exception 'no free code'; end if;
    end;
  end loop;
end;
$$;

-- لیست کدها (فقط مدیر)
create or replace function public.tipax_codes_list(pw text) returns jsonb
language plpgsql security definer set search_path = public as $$
begin
  perform public.tipax_admin_ok(pw);
  return coalesce((
    select jsonb_agg(jsonb_build_object(
      'code', code, 'label', label, 'model', model, 'ver', app_ver, 'banned', banned,
      'used', device_id is not null, 'created', created_at, 'activated', activated_at,
      'age', case when last_seen is null then null else extract(epoch from (now() - last_seen))::bigint end
    ) order by created_at desc)
    from public.tipax_codes
  ), '[]'::jsonb);
end;
$$;

create or replace function public.tipax_code_ban(pw text, p_code text, val boolean) returns void
language plpgsql security definer set search_path = public as $$
begin
  perform public.tipax_admin_ok(pw);
  update public.tipax_codes set banned = coalesce(val, true) where code = p_code;
end;
$$;

-- آزاد کردن کد از گوشی فعلی (برای عوض کردن گوشی)؛ گوشی قبلی قفل می‌شود
create or replace function public.tipax_code_reset(pw text, p_code text) returns void
language plpgsql security definer set search_path = public as $$
begin
  perform public.tipax_admin_ok(pw);
  update public.tipax_codes set device_id = null, model = '', app_ver = '', activated_at = null, last_seen = null where code = p_code;
end;
$$;

create or replace function public.tipax_code_label(pw text, p_code text, p_label text) returns void
language plpgsql security definer set search_path = public as $$
begin
  perform public.tipax_admin_ok(pw);
  update public.tipax_codes set label = left(btrim(coalesce(p_label, '')), 60) where code = p_code;
end;
$$;

create or replace function public.tipax_code_delete(pw text, p_code text) returns void
language plpgsql security definer set search_path = public as $$
begin
  perform public.tipax_admin_ok(pw);
  delete from public.tipax_codes where code = p_code;
end;
$$;

grant execute on function public.tipax_activate(text, text, text, text) to anon, authenticated;
grant execute on function public.tipax_ping(text, text, text, text) to anon, authenticated;
grant execute on function public.tipax_code_create(text, text) to anon, authenticated;
grant execute on function public.tipax_codes_list(text) to anon, authenticated;
grant execute on function public.tipax_code_ban(text, text, boolean) to anon, authenticated;
grant execute on function public.tipax_code_reset(text, text) to anon, authenticated;
grant execute on function public.tipax_code_label(text, text, text) to anon, authenticated;
grant execute on function public.tipax_code_delete(text, text) to anon, authenticated;

notify pgrst, 'reload schema';

-- ===== ۵) مدت اشتراک =====
-- ============================================================
--  مدت اشتراک (۱ ماهه / ۳ ماهه / ... / بی‌نهایت)
--  Supabase → SQL Editor → Run   (دوباره اجرا کردنش بی‌خطر است)
--  کدهای قبلی «بی‌نهایت» می‌مانند. مدت از اولین ورود کاربر شروع می‌شود.
-- ============================================================
alter table public.tipax_codes add column if not exists duration_days int;        -- خالی = بی‌نهایت
alter table public.tipax_codes add column if not exists expires_at timestamptz;   -- خالی = بی‌نهایت یا هنوز شروع نشده

-- ورود با کد: ok | invalid | used | banned | expired | locked
create or replace function public.tipax_activate(p_code text, p_id text, p_model text, p_ver text)
returns text
language plpgsql security definer set search_path = public as $$
declare r public.tipax_codes; f public.tipax_fails; v_found boolean;
begin
  if p_id is null or length(p_id) < 1 or length(p_id) > 80 then raise exception 'bad id'; end if;
  select * into f from public.tipax_fails where id = p_id;
  if found and f.n >= 8 and f.last > now() - interval '15 minutes' then return 'locked'; end if;

  select * into r from public.tipax_codes where code = btrim(coalesce(p_code, '')) for update;
  v_found := found;
  if not v_found or (r.device_id is not null and r.device_id <> p_id) then
    insert into public.tipax_fails (id, n, last) values (p_id, 1, now())
    on conflict (id) do update set
      n = case when public.tipax_fails.last < now() - interval '15 minutes' then 1 else public.tipax_fails.n + 1 end,
      last = now();
    return case when v_found then 'used' else 'invalid' end;
  end if;
  if r.banned then return 'banned'; end if;
  if r.expires_at is not null and r.expires_at <= now() then return 'expired'; end if;

  update public.tipax_codes set
    device_id = p_id,
    model = left(coalesce(p_model, ''), 60),
    app_ver = left(coalesce(p_ver, ''), 20),
    activated_at = coalesce(activated_at, now()),
    last_seen = now(),
    expires_at = case when expires_at is null and duration_days is not null
                      then now() + make_interval(days => duration_days) else expires_at end
  where code = r.code;
  delete from public.tipax_fails where id = p_id;
  return 'ok';
end;
$$;

-- هر چند ثانیه از گوشی: ok | banned | expired | invalid | used
create or replace function public.tipax_ping(p_code text, p_id text, p_model text, p_ver text)
returns text
language plpgsql security definer set search_path = public as $$
declare r public.tipax_codes;
begin
  select * into r from public.tipax_codes where code = btrim(coalesce(p_code, ''));
  if not found or r.device_id is null then return 'invalid'; end if;
  if r.device_id <> coalesce(p_id, '') then return 'used'; end if;
  update public.tipax_codes set
    model = case when coalesce(p_model, '') <> '' then left(p_model, 60) else model end,
    app_ver = case when coalesce(p_ver, '') <> '' then left(p_ver, 20) else app_ver end,
    last_seen = now()
  where code = r.code;
  if r.banned then return 'banned'; end if;
  if r.expires_at is not null and r.expires_at <= now() then return 'expired'; end if;
  return 'ok';
end;
$$;

-- ساخت کد با مدت (p_days خالی = بی‌نهایت)
drop function if exists public.tipax_code_create(text, text);
create or replace function public.tipax_code_create(pw text, p_label text, p_days int default null) returns text
language plpgsql security definer set search_path = public as $$
declare c text; i int := 0;
begin
  perform public.tipax_admin_ok(pw);
  loop
    c := (1000 + floor(random() * 9000))::int::text;
    begin
      insert into public.tipax_codes (code, label, duration_days)
      values (c, left(btrim(coalesce(p_label, '')), 60), case when coalesce(p_days, 0) > 0 then p_days else null end);
      return c;
    exception when unique_violation then
      i := i + 1;
      if i > 60 then raise exception 'no free code'; end if;
    end;
  end loop;
end;
$$;

-- لیست کدها
create or replace function public.tipax_codes_list(pw text) returns jsonb
language plpgsql security definer set search_path = public as $$
begin
  perform public.tipax_admin_ok(pw);
  return coalesce((
    select jsonb_agg(jsonb_build_object(
      'code', code, 'label', label, 'model', model, 'ver', app_ver, 'banned', banned,
      'used', device_id is not null, 'created', created_at, 'activated', activated_at,
      'days', duration_days,
      'left', case when expires_at is null then null else extract(epoch from (expires_at - now()))::bigint end,
      'age', case when last_seen is null then null else extract(epoch from (now() - last_seen))::bigint end
    ) order by created_at desc)
    from public.tipax_codes
  ), '[]'::jsonb);
end;
$$;

-- تغییر مدت اشتراک. p_days خالی/۰ = بی‌نهایت
-- p_mode: 'extend' = به پایان اشتراک فعلی اضافه شود | 'now' = از امروز حساب شود
create or replace function public.tipax_code_plan(pw text, p_code text, p_days int, p_mode text) returns void
language plpgsql security definer set search_path = public as $$
declare r public.tipax_codes;
begin
  perform public.tipax_admin_ok(pw);
  select * into r from public.tipax_codes where code = p_code for update;
  if not found then raise exception 'no code'; end if;
  if coalesce(p_days, 0) <= 0 then
    update public.tipax_codes set duration_days = null, expires_at = null where code = p_code;
  elsif r.device_id is null and r.expires_at is null then          -- هنوز کسی وارد نشده: از اولین ورود شروع می‌شود
    update public.tipax_codes set duration_days = p_days where code = p_code;
  else
    update public.tipax_codes set
      duration_days = p_days,
      expires_at = case when p_mode = 'extend'
                        then greatest(coalesce(r.expires_at, now()), now()) + make_interval(days => p_days)
                        else now() + make_interval(days => p_days) end
    where code = p_code;
  end if;
end;
$$;

grant execute on function public.tipax_activate(text, text, text, text) to anon, authenticated;
grant execute on function public.tipax_ping(text, text, text, text) to anon, authenticated;
grant execute on function public.tipax_code_create(text, text, int) to anon, authenticated;
grant execute on function public.tipax_codes_list(text) to anon, authenticated;
grant execute on function public.tipax_code_plan(text, text, int, text) to anon, authenticated;

notify pgrst, 'reload schema';


-- ====== تقسیم کار بین چند گوشی (docs/split_work.sql) ======
-- ============================================================
--  تقسیم کار بین چند گوشی (نسخه ۱.۱۳) - Supabase → SQL Editor → Run
--  یک‌بار اجرا کن. دوباره اجرا کردنش بی‌خطر است.
--  گوشی‌هایی که «همین فایل» را انتخاب کنند خودکار همدیگر را پیدا می‌کنند
--  و بارکدها بینشان مساوی تقسیم می‌شود (۵۰۰ تا روی ۲ گوشی = ۲۵۰ + ۲۵۰).
-- ============================================================
create table if not exists public.tipax_split (
  room      text not null,                       -- اثر انگشت فایل (هش بارکدها)
  dev       text not null,                       -- شناسه‌ی گوشی
  model     text not null default '',
  joined_at timestamptz not null default now(),  -- ترتیب ورود = شماره‌ی گوشی
  last_seen timestamptz not null default now(),
  primary key (room, dev)
);
alter table public.tipax_split enable row level security;
revoke all on public.tipax_split from anon, authenticated;

-- پیوستن/ضربان: لیست گوشی‌های زنده‌ی همین فایل را (به ترتیب ورود) برمی‌گرداند
create or replace function public.tipax_split_join(p_room text, p_dev text, p_model text)
returns jsonb
language plpgsql security definer set search_path = public as $$
begin
  if p_room is null or length(p_room) <> 32 or p_dev is null or length(p_dev) < 1 or length(p_dev) > 80 then
    raise exception 'bad args';
  end if;
  delete from public.tipax_split where last_seen < now() - interval '1 hour';
  insert into public.tipax_split (room, dev, model)
  values (p_room, p_dev, left(coalesce(p_model, ''), 60))
  on conflict (room, dev) do update set
    model = excluded.model,
    joined_at = case when public.tipax_split.last_seen < now() - interval '30 seconds'
                     then now() else public.tipax_split.joined_at end,
    last_seen = now();
  return coalesce((
    select jsonb_agg(jsonb_build_object('dev', dev, 'model', model) order by joined_at, dev)
    from public.tipax_split
    where room = p_room and last_seen > now() - interval '30 seconds'
  ), '[]'::jsonb);
end;
$$;

create or replace function public.tipax_split_leave(p_room text, p_dev text)
returns void
language plpgsql security definer set search_path = public as $$
begin
  delete from public.tipax_split where room = p_room and dev = p_dev;
end;
$$;

grant execute on function public.tipax_split_join(text, text, text) to anon, authenticated;
grant execute on function public.tipax_split_leave(text, text) to anon, authenticated;
