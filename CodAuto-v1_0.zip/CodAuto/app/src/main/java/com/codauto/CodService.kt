package com.codauto

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.TextView

class CodService : AccessibilityService() {

    companion object {
        @Volatile var instance: CodService? = null
        @Volatile var running = false
        @Volatile var status = "آماده"
        @Volatile var listener: (() -> Unit)? = null
    }

    private val h = Handler(Looper.getMainLooper())
    private var step = 0
    private var overlay: View? = null

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        if (running) stop("سرویس دسترسی خاموش شد")
        instance = null
        return super.onUnbind(intent)
    }

    fun start() {
        if (running) return
        running = true
        step = 0
        showOverlay()
        setStatus("شروع شد...")
        h.removeCallbacksAndMessages(null)
        h.postDelayed({ tick() }, 3000)
    }

    fun stop(msg: String) {
        running = false
        h.removeCallbacksAndMessages(null)
        hideOverlay()
        setStatus(msg)
    }

    private fun tick() {
        if (!running) return
        try {
            val s = Config.STEPS[step]
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION")
            (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(dm)
            // بازی افقی است: بزرگ‌تر = عرض، کوچک‌تر = ارتفاع
            val w = maxOf(dm.widthPixels, dm.heightPixels).toFloat()
            val hh = minOf(dm.widthPixels, dm.heightPixels).toFloat()
            val x = s.x / Config.REF_W * w
            val y = s.y / Config.REF_H * hh
            setStatus("لمس ${step + 1} از ${Config.STEPS.size}: ${s.name}")
            tapAt(x, y)
        } catch (e: Exception) {
            setStatus("خطای موقت؛ ادامه می‌دهم...")
        }
        step++
        var wait = Config.delay(this)
        if (step >= Config.STEPS.size) {
            step = 0
            wait = Config.cycleWait(this)
        }
        h.postDelayed({ tick() }, (wait * 1000).toLong())
    }

    private fun tapAt(x: Float, y: Float) {
        val p = Path().apply { moveTo(x, y) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 60))
            .build()
        dispatchGesture(g, null, null)
    }

    // ---------- دکمه‌ی شناور «توقف» (وقتی بازی بازه از اینجا می‌شه قطعش کرد) ----------
    private fun showOverlay() {
        if (overlay != null) return
        val tv = TextView(this).apply {
            text = "■ توقف"
            setTextColor(Color.WHITE)
            textSize = 14f
            setPadding(36, 24, 36, 24)
            background = GradientDrawable().apply {
                setColor(0xCCD32F2F.toInt())
                cornerRadius = 40f
            }
            setOnClickListener { stop("متوقف شد") }
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.START or Gravity.CENTER_VERTICAL
        lp.x = 16
        try {
            (getSystemService(WINDOW_SERVICE) as WindowManager).addView(tv, lp)
            overlay = tv
        } catch (e: Exception) {
        }
    }

    private fun hideOverlay() {
        overlay?.let {
            try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } catch (e: Exception) {}
        }
        overlay = null
    }

    private fun setStatus(msg: String) {
        status = msg
        Handler(Looper.getMainLooper()).post { listener?.invoke() }
    }
}
