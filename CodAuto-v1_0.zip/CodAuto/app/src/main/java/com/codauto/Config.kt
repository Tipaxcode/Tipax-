package com.codauto

import android.content.Context

object Config {
    /** رزولوشن اسکرین‌شات‌هایی که مختصات‌ها از روی آن‌ها گرفته شده. روی هر گوشی خودکار مقیاس می‌شود. */
    const val REF_W = 2340f
    const val REF_H = 1080f

    class Step(val name: String, val x: Float, val y: Float)

    /** ترتیب لمس‌ها. برای عوض کردن مختصات فقط همین لیست را ویرایش کن. */
    val STEPS = listOf(
        Step("دکمه قرمز", 2243f, 60f),
        Step("خروج (در با فلش)", 2240f, 72f),
        Step("دکمه خاکستری (التالی)", 2070f, 980f),
        Step("دکمه زرد (اللعب مرة أخرى)", 1700f, 995f)
    )

    val GAME_PACKAGES = listOf(
        "com.activision.callofduty.shooter", // جهانی
        "com.garena.game.codm",              // گارِنا
        "com.tencent.tmgp.cod"               // تنسنت
    )

    private fun prefs(c: Context) = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    /** فاصله بین دو لمس (ثانیه) */
    fun delay(c: Context): Float = prefs(c).getFloat("delay", 3f)
    fun setDelay(c: Context, v: Float) = prefs(c).edit().putFloat("delay", v).apply()

    /** صبر بعد از هر دور کامل، تا مسابقه‌ی بعدی شروع شود (ثانیه) */
    fun cycleWait(c: Context): Float = prefs(c).getFloat("cycle", 5f)
    fun setCycleWait(c: Context, v: Float) = prefs(c).edit().putFloat("cycle", v).apply()
}
