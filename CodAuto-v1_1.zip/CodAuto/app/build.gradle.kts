plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.codauto"
    compileSdk = 34

    // امضای ثابت: همه‌ی بیلدها با یک کلید امضا می‌شوند تا آپدیت روی نسخه‌ی نصب‌شده بنشیند.
    signingConfigs {
        getByName("debug") {
            storeFile = file("cod-release.jks")
            storePassword = "codauto2026"
            keyAlias = "cod"
            keyPassword = "codauto2026"
        }
    }

    defaultConfig {
        applicationId = "com.codauto"
        minSdk = 24
        targetSdk = 34
        versionCode = 2
        versionName = "1.1"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
