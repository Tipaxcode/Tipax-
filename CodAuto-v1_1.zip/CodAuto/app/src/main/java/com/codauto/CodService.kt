package com.codauto

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.ScreenshotResult
import android.accessibilityservice.AccessibilityService.TakeScreenshotCallback
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Display
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.TextView

class CodService : AccessibilityService() {

    companion object {
        @Volatile var instance: CodService? = null
        @Volatile var running = false
        @Volatile var status = "آماده"
        @Volatile var listener: (() -> Unit)? = null

        /** اگر دکمه بعد از لمس هنوز مانده بود، بعد از این مدت دوباره لمس می‌شود */
        private const val RETRY_MS = 8000L
    }

    private val h = Handler(Looper.getMainLooper())
    private var overlay: View? = null
    private val armed = BooleanArray(Config.STEPS.size) { true }
    private val tappedAt = LongArray(Config.STEPS.size)

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        if (running) stop("سرویس دسترسی خاموش شد")
        instance = null
        return super.onUnbind(intent)
    }

    fun start(): Boolean {
        if (running) return true
        if (Build.VERSION.SDK_INT < 30) {
            setStatus("این برنامه اندروید ۱۱ یا بالاتر می‌خواهد")
            return false
        }
        running = true
        for (i in armed.indices) { armed[i] = true; tappedAt[i] = 0L }
        showOverlay()
        setStatus("شروع شد؛ منتظر دیدن دکمه‌ها...")
        h.removeCallbacksAndMessages(null)
        schedule(3000)
        return true
    }

    fun stop(msg: String) {
        running = false
        h.removeCallbacksAndMessages(null)
        hideOverlay()
        setStatus(msg)
    }

    private fun schedule(ms: Long) {
        h.postDelayed({ if (running) grab() }, ms)
    }

    // ---------- گرفتن اسکرین‌شات و دیدن دکمه‌ها ----------
    private fun grab() {
        if (Build.VERSION.SDK_INT < 30) return
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
                override fun onSuccess(result: ScreenshotResult) {
                    var bmp: Bitmap? = null
                    try {
                        val hw = Bitmap.wrapHardwareBuffer(result.hardwareBuffer, result.colorSpace)
                        bmp = hw?.copy(Bitmap.Config.ARGB_8888, false)
                        hw?.recycle()
                    } catch (e: Exception) {
                    }
                    try { result.hardwareBuffer.close() } catch (e: Exception) {}
                    if (!running) { bmp?.recycle(); return }
                    var next = (Config.scan(this@CodService) * 1000).toLong()
                    if (bmp != null) {
                        try {
                            if (inspect(bmp)) next = (Config.after(this@CodService) * 1000).toLong()
                        } catch (e: Exception) {
                            setStatus("خطای موقت؛ ادامه می‌دهم...")
                        }
                        bmp.recycle()
                    }
                    schedule(next)
                }

                override fun onFailure(errorCode: Int) {
                    if (!running) return
                    setStatus("اسکرین‌شات نشد (کد $errorCode)؛ دوباره تلاش می‌کنم")
                    schedule((Config.scan(this@CodService) * 1000).toLong() + 500)
                }
            })
        } catch (e: Exception) {
            setStatus("خطای موقت؛ ادامه می‌دهم...")
            schedule(2000)
        }
    }

    /** اگه دکمه‌ای دیده شد لمسش می‌کند و true برمی‌گرداند. */
    private fun inspect(bmp: Bitmap): Boolean {
        if (bmp.width < bmp.height) {
            setStatus("بازی در حالت افقی نیست")
            return false
        }
        val now = SystemClock.elapsedRealtime()
        var tapped = false
        for ((i, s) in Config.STEPS.withIndex()) {
            val match = s.spots.all { check(bmp, it) }
            if (!match) { armed[i] = true; continue }
            if (tapped) continue
            if (!armed[i] && now - tappedAt[i] < RETRY_MS) continue
            tapAt(s.tapX / Config.REF_W * bmp.width, s.tapY / Config.REF_H * bmp.height)
            armed[i] = false
            tappedAt[i] = now
            tapped = true
            setStatus("دیدم و زدم: ${s.name}")
        }
        if (!tapped) setStatus("در انتظار دکمه‌ها...")
        return tapped
    }

    private fun check(bmp: Bitmap, sp: Config.Spot): Boolean {
        val cx = (sp.x / Config.REF_W * bmp.width).toInt()
        val cy = (sp.y / Config.REF_H * bmp.height).toInt()
        var r = 0; var g = 0; var b = 0; var n = 0
        for (xx in (cx - 4)..(cx + 4)) for (yy in (cy - 4)..(cy + 4)) {
            if (xx < 0 || yy < 0 || xx >= bmp.width || yy >= bmp.height) continue
            val p = bmp.getPixel(xx, yy)
            r += Color.red(p); g += Color.green(p); b += Color.blue(p); n++
        }
        if (n == 0) return false
        return sp.ok(r / n, g / n, b / n) == sp.want
    }

    private fun tapAt(x: Float, y: Float) {
        val p = Path().apply { moveTo(x, y) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 60))
            .build()
        dispatchGesture(g, null, null)
    }

    // ---------- دکمه‌ی شناور «توقف» ----------
    private fun showOverlay() {
        if (overlay != null) return
        val tv = TextView(this).apply {
            text = "■ توقف"
            setTextColor(Color.WHITE)
            textSize = 14f
            setPadding(36, 24, 36, 24)
            background = GradientDrawable().apply {
                setColor(0xCCD32F2F.toInt())
                cornerRadius = 40f
            }
            setOnClickListener { stop("متوقف شد") }
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.START or Gravity.CENTER_VERTICAL
        lp.x = 16
        try {
            (getSystemService(WINDOW_SERVICE) as WindowManager).addView(tv, lp)
            overlay = tv
        } catch (e: Exception) {
        }
    }

    private fun hideOverlay() {
        overlay?.let {
            try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } catch (e: Exception) {}
        }
        overlay = null
    }

    private fun setStatus(msg: String) {
        status = msg
        Handler(Looper.getMainLooper()).post { listener?.invoke() }
    }
}
