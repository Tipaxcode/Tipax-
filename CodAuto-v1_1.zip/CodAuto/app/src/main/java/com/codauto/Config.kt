package com.codauto

import android.content.Context

object Config {
    /** رزولوشن اسکرین‌شات‌هایی که مختصات‌ها از روی آن‌ها گرفته شده. روی هر گوشی خودکار مقیاس می‌شود. */
    const val REF_W = 2340f
    const val REF_H = 1080f

    // ---------- تشخیص رنگ (RGB) ----------
    private val YELLOW: (Int, Int, Int) -> Boolean = { r, g, b -> r > 200 && g > 165 && b < 140 && r - b > 90 }
    private val RED: (Int, Int, Int) -> Boolean = { r, g, b -> r > 170 && g < 145 && b < 145 && r - g > 55 }
    private val LIGHT_BLUE: (Int, Int, Int) -> Boolean = { r, g, b -> r in 130..225 && g in 175..240 && b in 190..240 && b - r > 20 }
    private val GRAY_BLUE: (Int, Int, Int) -> Boolean = { r, g, b -> r in 150..230 && g in 155..235 && b in 170..240 && b - r in 5..35 }

    /** یک نقطه‌ی بررسی: رنگش باید با ok بخواند (want=true) یا نخواند (want=false). */
    class Spot(val x: Float, val y: Float, val ok: (Int, Int, Int) -> Boolean, val want: Boolean = true)

    /** وقتی همه‌ی spots جور بود، (tapX, tapY) لمس می‌شود. */
    class Step(val name: String, val tapX: Float, val tapY: Float, val spots: List<Spot>)

    /** ترتیب بررسی. مختصات‌ها برای صفحه‌ی 2340x1080 هستند. */
    val STEPS = listOf(
        Step("دکمه قرمز", 2243f, 60f, listOf(
            Spot(2200f, 45f, RED), Spot(2285f, 75f, RED),
            Spot(1530f, 960f, YELLOW)
        )),
        Step("خروج (در با فلش)", 2240f, 72f, listOf(
            Spot(2205f, 55f, GRAY_BLUE), Spot(2260f, 95f, GRAY_BLUE),
            Spot(2085f, 50f, YELLOW)
        )),
        Step("دکمه خاکستری (التالی)", 2070f, 980f, listOf(
            Spot(1870f, 950f, LIGHT_BLUE), Spot(2280f, 1010f, LIGHT_BLUE),
            Spot(1530f, 960f, YELLOW, want = false)
        )),
        Step("دکمه زرد (اللعب مرة أخرى)", 1700f, 995f, listOf(
            Spot(1530f, 960f, YELLOW), Spot(1520f, 1030f, YELLOW)
        ))
    )

    val GAME_PACKAGES = listOf(
        "com.activision.callofduty.shooter", // جهانی
        "com.garena.game.codm",              // گارِنا
        "com.tencent.tmgp.cod"               // تنسنت
    )

    private fun prefs(c: Context) = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    /** هر چند ثانیه یک بار صفحه چک شود (اندروید بیشتر از ثانیه‌ای یک اسکرین‌شات اجازه نمی‌دهد) */
    fun scan(c: Context): Float = prefs(c).getFloat("scan", 1.5f)
    fun setScan(c: Context, v: Float) = prefs(c).edit().putFloat("scan", v).apply()

    /** صبر بعد از هر لمس (ثانیه) */
    fun after(c: Context): Float = prefs(c).getFloat("after", 2f)
    fun setAfter(c: Context, v: Float) = prefs(c).edit().putFloat("after", v).apply()
}
