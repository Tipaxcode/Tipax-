package com.codauto

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val BG = 0xFF14161B.toInt()
    private val CARD = 0xFF1E2128.toInt()
    private val YELLOW = 0xFFFFC107.toInt()
    private val RED = 0xFFD32F2F.toInt()
    private val GRAY = 0xFF9AA0A6.toInt()

    private lateinit var accText: TextView
    private lateinit var statusText: TextView
    private lateinit var delayEdit: EditText
    private lateinit var cycleEdit: EditText
    private lateinit var startBtn: Button

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(24))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        root.addView(text("COD Auto", 26f, YELLOW, bold = true))
        root.addView(text("هر وقت دکمه‌های آخر مسابقه را دید، خودکار می‌زند", 14f, GRAY))

        // مرحله ۱: دسترسی
        val c1 = card()
        c1.addView(text("۱) دسترسی برنامه", 16f, Color.WHITE, bold = true))
        accText = text("", 14f, GRAY)
        c1.addView(accText)
        c1.addView(button("فعال‌سازی دسترسی (Accessibility)", 0xFF2D3340.toInt(), Color.WHITE) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(c1)

        // مرحله ۲: تنظیمات
        val c2 = card()
        c2.addView(text("۲) تنظیمات", 16f, Color.WHITE, bold = true))
        c2.addView(text("هر چند ثانیه صفحه چک شود (حداقل ۱.۱)", 13f, GRAY))
        delayEdit = edit(Config.scan(this))
        c2.addView(delayEdit)
        c2.addView(text("صبر بعد از هر لمس (ثانیه)", 13f, GRAY))
        cycleEdit = edit(Config.after(this))
        c2.addView(cycleEdit)
        root.addView(c2)

        // مرحله ۳: وضعیت و شروع
        val c3 = card()
        c3.addView(text("۳) وضعیت", 16f, Color.WHITE, bold = true))
        statusText = text("", 14f, YELLOW)
        c3.addView(statusText)
        startBtn = button("شروع", YELLOW, Color.BLACK) { toggle() }
        c3.addView(startBtn)
        root.addView(c3)

        val sv = ScrollView(this).apply {
            setBackgroundColor(BG)
            addView(root, MATCH_PARENT, WRAP_CONTENT)
        }
        setContentView(sv)
    }

    override fun onResume() {
        super.onResume()
        CodService.listener = { refresh() }
        refresh()
    }

    override fun onPause() {
        super.onPause()
        CodService.listener = null
    }

    private fun toggle() {
        val svc = CodService.instance
        if (CodService.running) {
            svc?.stop("متوقف شد")
            refresh()
            return
        }
        if (svc == null) {
            Toast.makeText(this, "اول دسترسی Accessibility را روشن کن", Toast.LENGTH_LONG).show()
            return
        }
        if (android.os.Build.VERSION.SDK_INT < 30) {
            Toast.makeText(this, "این برنامه اندروید ۱۱ یا بالاتر می‌خواهد", Toast.LENGTH_LONG).show()
            return
        }
        val d = parse(delayEdit.text.toString(), 1.5f).coerceIn(1.1f, 30f)
        val cy = parse(cycleEdit.text.toString(), 2f).coerceIn(0.5f, 30f)
        Config.setScan(this, d)
        Config.setAfter(this, cy)

        val intent = Config.GAME_PACKAGES.firstNotNullOfOrNull { packageManager.getLaunchIntentForPackage(it) }
        if (intent == null) {
            Toast.makeText(this, "بازی Call of Duty Mobile روی گوشی نصب نیست", Toast.LENGTH_LONG).show()
            return
        }
        startActivity(intent)
        if (!svc.start()) return
        refresh()
    }

    private fun refresh() {
        val on = CodService.instance != null
        accText.text = if (on) "✅ دسترسی فعال است"
        else "❌ هنوز فعال نشده؛ دکمه‌ی پایین را بزن و «COD Auto» را روشن کن"
        statusText.text = CodService.status
        if (CodService.running) {
            startBtn.text = "توقف"
            startBtn.background = pill(RED)
            startBtn.setTextColor(Color.WHITE)
        } else {
            startBtn.text = "شروع"
            startBtn.background = pill(YELLOW)
            startBtn.setTextColor(Color.BLACK)
        }
    }

    // ---------- ابزارهای ساخت UI ----------
    private fun pill(color: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(12).toFloat()
    }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(16))
        background = GradientDrawable().apply {
            setColor(CARD)
            cornerRadius = dp(16).toFloat()
        }
        layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(12) }
    }

    private fun text(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t
        textSize = size
        setTextColor(color)
        gravity = Gravity.START
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        setPadding(0, dp(4), 0, dp(4))
    }

    private fun button(t: String, bg: Int, fg: Int, onClick: () -> Unit) = Button(this).apply {
        text = t
        setTextColor(fg)
        background = pill(bg)
        isAllCaps = false
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, dp(52)).apply { topMargin = dp(10) }
    }

    private fun edit(v: Float) = EditText(this).apply {
        setText(if (v % 1f == 0f) v.toInt().toString() else v.toString())
        inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        setTextColor(Color.WHITE)
        setSingleLine()
        gravity = Gravity.CENTER
        background = GradientDrawable().apply {
            setColor(0xFF2D3340.toInt())
            cornerRadius = dp(10).toFloat()
        }
        setPadding(dp(12), dp(10), dp(12), dp(10))
    }

    /** اعداد فارسی/عربی را هم می‌فهمد */
    private fun parse(s: String, def: Float): Float {
        val sb = StringBuilder()
        for (ch in s.trim()) {
            sb.append(
                when (ch) {
                    in '۰'..'۹' -> '0' + (ch - '۰')
                    in '٠'..'٩' -> '0' + (ch - '٠')
                    '٫', ',', '،' -> '.'
                    else -> ch
                }
            )
        }
        return sb.toString().toFloatOrNull() ?: def
    }
}
