-- ============================================================
--  مدت اشتراک (۱ ماهه / ۳ ماهه / ... / بی‌نهایت)
--  Supabase → SQL Editor → Run   (دوباره اجرا کردنش بی‌خطر است)
--  کدهای قبلی «بی‌نهایت» می‌مانند. مدت از اولین ورود کاربر شروع می‌شود.
-- ============================================================
alter table public.tipax_codes add column if not exists duration_days int;        -- خالی = بی‌نهایت
alter table public.tipax_codes add column if not exists expires_at timestamptz;   -- خالی = بی‌نهایت یا هنوز شروع نشده

-- ورود با کد: ok | invalid | used | banned | expired | locked
create or replace function public.tipax_activate(p_code text, p_id text, p_model text, p_ver text)
returns text
language plpgsql security definer set search_path = public as $$
declare r public.tipax_codes; f public.tipax_fails; v_found boolean;
begin
  if p_id is null or length(p_id) < 1 or length(p_id) > 80 then raise exception 'bad id'; end if;
  select * into f from public.tipax_fails where id = p_id;
  if found and f.n >= 8 and f.last > now() - interval '15 minutes' then return 'locked'; end if;

  select * into r from public.tipax_codes where code = btrim(coalesce(p_code, '')) for update;
  v_found := found;
  if not v_found or (r.device_id is not null and r.device_id <> p_id) then
    insert into public.tipax_fails (id, n, last) values (p_id, 1, now())
    on conflict (id) do update set
      n = case when public.tipax_fails.last < now() - interval '15 minutes' then 1 else public.tipax_fails.n + 1 end,
      last = now();
    return case when v_found then 'used' else 'invalid' end;
  end if;
  if r.banned then return 'banned'; end if;
  if r.expires_at is not null and r.expires_at <= now() then return 'expired'; end if;

  update public.tipax_codes set
    device_id = p_id,
    model = left(coalesce(p_model, ''), 60),
    app_ver = left(coalesce(p_ver, ''), 20),
    activated_at = coalesce(activated_at, now()),
    last_seen = now(),
    expires_at = case when expires_at is null and duration_days is not null
                      then now() + make_interval(days => duration_days) else expires_at end
  where code = r.code;
  delete from public.tipax_fails where id = p_id;
  return 'ok';
end;
$$;

-- هر چند ثانیه از گوشی: ok | banned | expired | invalid | used
create or replace function public.tipax_ping(p_code text, p_id text, p_model text, p_ver text)
returns text
language plpgsql security definer set search_path = public as $$
declare r public.tipax_codes;
begin
  select * into r from public.tipax_codes where code = btrim(coalesce(p_code, ''));
  if not found or r.device_id is null then return 'invalid'; end if;
  if r.device_id <> coalesce(p_id, '') then return 'used'; end if;
  update public.tipax_codes set
    model = case when coalesce(p_model, '') <> '' then left(p_model, 60) else model end,
    app_ver = case when coalesce(p_ver, '') <> '' then left(p_ver, 20) else app_ver end,
    last_seen = now()
  where code = r.code;
  if r.banned then return 'banned'; end if;
  if r.expires_at is not null and r.expires_at <= now() then return 'expired'; end if;
  return 'ok';
end;
$$;

-- ساخت کد با مدت (p_days خالی = بی‌نهایت)
drop function if exists public.tipax_code_create(text, text);
create or replace function public.tipax_code_create(pw text, p_label text, p_days int default null) returns text
language plpgsql security definer set search_path = public as $$
declare c text; i int := 0;
begin
  perform public.tipax_admin_ok(pw);
  loop
    c := (1000 + floor(random() * 9000))::int::text;
    begin
      insert into public.tipax_codes (code, label, duration_days)
      values (c, left(btrim(coalesce(p_label, '')), 60), case when coalesce(p_days, 0) > 0 then p_days else null end);
      return c;
    exception when unique_violation then
      i := i + 1;
      if i > 60 then raise exception 'no free code'; end if;
    end;
  end loop;
end;
$$;

-- لیست کدها
create or replace function public.tipax_codes_list(pw text) returns jsonb
language plpgsql security definer set search_path = public as $$
begin
  perform public.tipax_admin_ok(pw);
  return coalesce((
    select jsonb_agg(jsonb_build_object(
      'code', code, 'label', label, 'model', model, 'ver', app_ver, 'banned', banned,
      'used', device_id is not null, 'created', created_at, 'activated', activated_at,
      'days', duration_days,
      'left', case when expires_at is null then null else extract(epoch from (expires_at - now()))::bigint end,
      'age', case when last_seen is null then null else extract(epoch from (now() - last_seen))::bigint end
    ) order by created_at desc)
    from public.tipax_codes
  ), '[]'::jsonb);
end;
$$;

-- تغییر مدت اشتراک. p_days خالی/۰ = بی‌نهایت
-- p_mode: 'extend' = به پایان اشتراک فعلی اضافه شود | 'now' = از امروز حساب شود
create or replace function public.tipax_code_plan(pw text, p_code text, p_days int, p_mode text) returns void
language plpgsql security definer set search_path = public as $$
declare r public.tipax_codes;
begin
  perform public.tipax_admin_ok(pw);
  select * into r from public.tipax_codes where code = p_code for update;
  if not found then raise exception 'no code'; end if;
  if coalesce(p_days, 0) <= 0 then
    update public.tipax_codes set duration_days = null, expires_at = null where code = p_code;
  elsif r.device_id is null and r.expires_at is null then          -- هنوز کسی وارد نشده: از اولین ورود شروع می‌شود
    update public.tipax_codes set duration_days = p_days where code = p_code;
  else
    update public.tipax_codes set
      duration_days = p_days,
      expires_at = case when p_mode = 'extend'
                        then greatest(coalesce(r.expires_at, now()), now()) + make_interval(days => p_days)
                        else now() + make_interval(days => p_days) end
    where code = p_code;
  end if;
end;
$$;

grant execute on function public.tipax_activate(text, text, text, text) to anon, authenticated;
grant execute on function public.tipax_ping(text, text, text, text) to anon, authenticated;
grant execute on function public.tipax_code_create(text, text, int) to anon, authenticated;
grant execute on function public.tipax_codes_list(text) to anon, authenticated;
grant execute on function public.tipax_code_plan(text, text, int, text) to anon, authenticated;

notify pgrst, 'reload schema';
