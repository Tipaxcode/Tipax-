-- ============================================================
--  تقسیم کار بین چند گوشی (نسخه ۱.۱۳) - Supabase → SQL Editor → Run
--  یک‌بار اجرا کن. دوباره اجرا کردنش بی‌خطر است.
--  گوشی‌هایی که «همین فایل» را انتخاب کنند خودکار همدیگر را پیدا می‌کنند
--  و بارکدها بینشان مساوی تقسیم می‌شود (۵۰۰ تا روی ۲ گوشی = ۲۵۰ + ۲۵۰).
-- ============================================================
create table if not exists public.tipax_split (
  room      text not null,                       -- اثر انگشت فایل (هش بارکدها)
  dev       text not null,                       -- شناسه‌ی گوشی
  model     text not null default '',
  joined_at timestamptz not null default now(),  -- ترتیب ورود = شماره‌ی گوشی
  last_seen timestamptz not null default now(),
  primary key (room, dev)
);
alter table public.tipax_split enable row level security;
revoke all on public.tipax_split from anon, authenticated;

-- پیوستن/ضربان: لیست گوشی‌های زنده‌ی همین فایل را (به ترتیب ورود) برمی‌گرداند
create or replace function public.tipax_split_join(p_room text, p_dev text, p_model text)
returns jsonb
language plpgsql security definer set search_path = public as $$
begin
  if p_room is null or length(p_room) <> 32 or p_dev is null or length(p_dev) < 1 or length(p_dev) > 80 then
    raise exception 'bad args';
  end if;
  delete from public.tipax_split where last_seen < now() - interval '1 hour';
  insert into public.tipax_split (room, dev, model)
  values (p_room, p_dev, left(coalesce(p_model, ''), 60))
  on conflict (room, dev) do update set
    model = excluded.model,
    joined_at = case when public.tipax_split.last_seen < now() - interval '30 seconds'
                     then now() else public.tipax_split.joined_at end,
    last_seen = now();
  return coalesce((
    select jsonb_agg(jsonb_build_object('dev', dev, 'model', model) order by joined_at, dev)
    from public.tipax_split
    where room = p_room and last_seen > now() - interval '30 seconds'
  ), '[]'::jsonb);
end;
$$;

create or replace function public.tipax_split_leave(p_room text, p_dev text)
returns void
language plpgsql security definer set search_path = public as $$
begin
  delete from public.tipax_split where room = p_room and dev = p_dev;
end;
$$;

grant execute on function public.tipax_split_join(text, text, text) to anon, authenticated;
grant execute on function public.tipax_split_leave(text, text) to anon, authenticated;
