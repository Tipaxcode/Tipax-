-- ============================================================
--  نمایش زمان باقی‌مانده‌ی اشتراک به کاربر (کنار اسم بالای برنامه)
--  Supabase → SQL Editor → Run   (دوباره اجرا کردنش بی‌خطر است)
--  خروجی: none | unlimited | تعداد ثانیه‌ی باقی‌مانده (منفی = تمام شده)
-- ============================================================
create or replace function public.tipax_sub_info(p_code text, p_id text)
returns text
language plpgsql security definer set search_path = public as $$
declare r public.tipax_codes;
begin
  select * into r from public.tipax_codes where code = btrim(coalesce(p_code, ''));
  if not found or r.device_id is null or r.device_id <> coalesce(p_id, '') then return 'none'; end if;
  if r.expires_at is null then return 'unlimited'; end if;
  return extract(epoch from (r.expires_at - now()))::bigint::text;
end;
$$;
grant execute on function public.tipax_sub_info(text, text) to anon, authenticated;
notify pgrst, 'reload schema';
