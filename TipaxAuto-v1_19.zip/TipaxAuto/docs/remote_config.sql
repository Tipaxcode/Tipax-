-- ============================================================
--  تنظیمات راه‌دور (رنگ، متن، تأخیر، روش ثبت) - بعد از supabase_setup.sql یک‌بار اجرا کن
--  دوباره اجرا کردنش بی‌خطر است. نسخه‌های قدیمی برنامه فقط ستون active را می‌خوانند و خراب نمی‌شوند.
-- ============================================================
-- اگر جدول از قبل بدون این ستون ساخته شده بود، اضافه‌اش می‌کند
alter table public.tipax_app_status
  add column if not exists updated_at timestamptz not null default now();

alter table public.tipax_app_status
  add column if not exists config jsonb not null default '{}'::jsonb;

create or replace function public.set_tipax_config(pw text, cfg jsonb)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if not exists (
    select 1 from public.tipax_admin
    where id = 1
      and pw_hash = encode(sha256(convert_to(coalesce(pw, ''), 'UTF8')), 'hex')
  ) then
    raise exception 'wrong password';
  end if;
  update public.tipax_app_status
     set config = coalesce(cfg, '{}'::jsonb), updated_at = now()
   where id = 1;
end;
$$;

revoke all on function public.set_tipax_config(text, jsonb) from public;
grant execute on function public.set_tipax_config(text, jsonb) to anon, authenticated;

-- بعد از ساخت ستون، کش API سوپابیس را تازه می‌کند (بدون این، گاهی ستون جدید دیده نمی‌شود)
notify pgrst, 'reload schema';
