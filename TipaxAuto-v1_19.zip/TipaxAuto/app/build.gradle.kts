plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.tipaxauto"
    compileSdk = 34

    // امضای ثابت: همه‌ی بیلدها (حتی روی گیت‌هاب) با همین کلید امضا می‌شوند تا آپدیت روی نسخه‌ی نصب‌شده بنشیند.
    signingConfigs {
        getByName("debug") {
            storeFile = file("tipax-release.jks")
            storePassword = "tipax2026"
            keyAlias = "tipax"
            keyPassword = "tipax2026"
        }
    }

    defaultConfig {
        applicationId = "com.tipaxauto"
        minSdk = 24
        targetSdk = 34
        versionCode = 19
        versionName = "1.18"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
