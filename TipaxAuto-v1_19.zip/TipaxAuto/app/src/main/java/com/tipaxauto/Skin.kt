package com.tipaxauto

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ClipDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.RippleDrawable
import android.graphics.drawable.StateListDrawable
import android.view.Gravity
import org.json.JSONObject

/**
 * تنظیمات راه‌دور (رنگ‌ها، متن‌ها، تأخیر، روش ثبت) که از Supabase می‌آید و در حافظه‌ی گوشی نگه داشته می‌شود.
 * هر کلیدی که نباشد، همان مقدار پیش‌فرضِ داخل برنامه استفاده می‌شود.
 */
object Skin {
    private const val KEY = "remote_config"
    @Volatile private var cfg = JSONObject()

    fun load(ctx: Context) {
        set(ctx.getSharedPreferences(Gate.PREFS, Context.MODE_PRIVATE).getString(KEY, "{}") ?: "{}")
    }

    fun save(ctx: Context, raw: String) {
        ctx.getSharedPreferences(Gate.PREFS, Context.MODE_PRIVATE).edit().putString(KEY, raw).apply()
        set(raw)
    }

    private fun set(raw: String) {
        cfg = try { JSONObject(raw) } catch (_: Exception) { JSONObject() }
    }

    fun col(key: String, def: Int): Int {
        val v = cfg.optJSONObject("colors")?.optString(key, "") ?: ""
        if (v.isEmpty() || v == "null") return def
        return try { Color.parseColor(v) } catch (_: Exception) { def }
    }

    fun col(key: String, def: String): Int = col(key, Color.parseColor(def))

    fun text(key: String, def: String): String {
        val v = cfg.optJSONObject("texts")?.optString(key, "") ?: ""
        return if (v.isBlank() || v == "null") def else v
    }

    /** تأخیر اجباری (ثانیه)؛ null یعنی هر گوشی تنظیم خودش را دارد. */
    val delaySec: Double?
        get() {
            val d = cfg.optDouble("delay", Double.NaN)
            return if (d.isNaN()) null else d
        }

    /** روش ثبت اجباری (۰، ۱ یا ۲)؛ null یعنی انتخابِ خودِ کاربر. */
    val mode: Int?
        get() {
            val m = cfg.optInt("mode", -1)
            return if (m in 0..2) m else null
        }

    /** تعداد بارکد تا «برگشت و ورود دوباره»ی اجباری؛ null یعنی انتخابِ خودِ کاربر. */
    val backEvery: Int?
        get() {
            val b = cfg.optInt("back_every", -1)
            return if (b >= 0) b else null
        }

    /** اطلاعات آپدیتی که مدیر از پنل منتشر کرده. */
    class UpdateInfo(val code: Int, val name: String, val url: String, val notes: String, val force: Boolean, val page: String)

    /** آپدیت جدید (اگر مدیر منتشر کرده و نسخه‌ی آن از نسخه‌ی نصب‌شده بالاتر است)، وگرنه null. */
    fun update(ctx: Context): UpdateInfo? {
        val u = cfg.optJSONObject("update") ?: return null
        if (!u.optBoolean("on", true)) return null
        val code = u.optInt("code", 0)
        val url = u.optString("url", "").trim()
        if (code <= 0 || !(url.startsWith("https://") || url.startsWith("http://"))) return null
        if (code <= installedCode(ctx)) return null
        // اگر نام نسخه‌ی منتشرشده با نسخه‌ی نصب‌شده یکی است (مثلاً مدیر کد را بالا زده ولی APK همان نسخه است) اعلان نشان داده نشود
        val nm = u.optString("name", "").trim()
        if (nm.isNotEmpty() && nm == installedName(ctx).trim()) return null
        return UpdateInfo(code, u.optString("name", "").trim(), url, u.optString("notes", "").trim(), u.optBoolean("force", false), u.optString("page", "").trim())
    }

    @Suppress("DEPRECATION")
    fun installedCode(ctx: Context): Long = try {
        val pi = ctx.packageManager.getPackageInfo(ctx.packageName, 0)
        if (android.os.Build.VERSION.SDK_INT >= 28) pi.longVersionCode else pi.versionCode.toLong()
    } catch (_: Exception) { Long.MAX_VALUE }

    @Suppress("DEPRECATION")
    fun installedName(ctx: Context): String = try {
        ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: ""
    } catch (_: Exception) { "" }

    private const val KEY_UPD_SKIP = "update_skipped_code"
    fun skippedUpdate(ctx: Context): Int = ctx.getSharedPreferences(Gate.PREFS, Context.MODE_PRIVATE).getInt(KEY_UPD_SKIP, 0)
    fun skipUpdate(ctx: Context, code: Int) {
        ctx.getSharedPreferences(Gate.PREFS, Context.MODE_PRIVATE).edit().putInt(KEY_UPD_SKIP, code).apply()
    }

    /** اگر این مقدار عوض شود، ظاهر برنامه باید دوباره ساخته شود. */
    fun visualKey(): String =
        (cfg.optJSONObject("colors")?.toString() ?: "") + "|" + (cfg.optJSONObject("texts")?.toString() ?: "") +
            "|" + (cfg.optJSONObject("update")?.toString() ?: "")

    private fun px(ctx: Context, dp: Float) = (dp * ctx.resources.displayMetrics.density).toInt().coerceAtLeast(1)

    private fun inner(d: Drawable): GradientDrawable = (d as LayerDrawable).getDrawable(0) as GradientDrawable

    private fun tile(ctx: Context, d: Drawable, key: String) {
        (d as GradientDrawable).apply {
            setColor(col(key, "#01784B"))
            setStroke(px(ctx, 3f), col("green_soft", "#E3F2EA"))
        }
    }

    /** همان drawableهای XML را برمی‌دارد و رنگ‌هایش را با تنظیمات راه‌دور عوض می‌کند. */
    fun bg(ctx: Context, id: Int): Drawable {
        val d = ctx.resources.getDrawable(id, ctx.theme).mutate()
        try {
            when (id) {
                R.drawable.bg_header ->
                    inner(d).setColors(intArrayOf(col("header_start", "#00573A"), col("header_end", "#01784B")))
                R.drawable.btn_primary ->
                    inner(d).setColors(intArrayOf(col("green", "#01784B"), col("green_mid", "#1E9462")))
                R.drawable.btn_tonal -> inner(d).setColor(col("green_soft", "#E3F2EA"))
                R.drawable.btn_danger -> inner(d).setStroke(px(ctx, 1.6f), col("green", "#01784B"))
                R.drawable.bg_circle_danger -> inner(d).setColor(col("green_soft", "#E3F2EA"))
                R.drawable.bg_chip -> (d as GradientDrawable).setColor(col("green_soft", "#E3F2EA"))
                R.drawable.bg_screen ->
                    (d as GradientDrawable).setColors(intArrayOf(col("bg_top", "#E4F1E9"), col("bg_bottom", "#F7FAF8")))
                R.drawable.bg_card -> (d as GradientDrawable).apply {
                    setColor(col("card_bg", "#FFFFFF"))
                    setStroke(px(ctx, 1f), col("card_stroke", "#D3E8DB"))
                }
                R.drawable.bg_input -> (d as GradientDrawable).apply {
                    setColor(col("input_bg", "#F5F9F6"))
                    setStroke(px(ctx, 1f), col("input_stroke", "#D5E4D8"))
                }
                R.drawable.bg_fileinfo -> (d as GradientDrawable).apply {
                    setColor(col("input_bg", "#F5F9F6"))
                    setStroke(px(ctx, 1.2f), col("input_stroke", "#C9DBCD"), px(ctx, 6f).toFloat(), px(ctx, 4f).toFloat())
                }
                R.drawable.tile_green -> tile(ctx, d, "tile_1")
                R.drawable.tile_blue -> tile(ctx, d, "tile_2")
                R.drawable.tile_amber -> tile(ctx, d, "tile_3")
                R.drawable.tile_purple -> tile(ctx, d, "tile_4")
                R.drawable.tile_teal -> tile(ctx, d, "tile_5")
                R.drawable.option_bg -> return optionBg(ctx)
                R.drawable.progress_bar -> return progress(ctx)
            }
        } catch (_: Exception) {
            // اگر چیزی نخواند، همان drawable پیش‌فرض
        }
        return d
    }

    private fun optionBg(ctx: Context): Drawable {
        val on = GradientDrawable().apply {
            setColor(col("green_soft", "#E3F2EA"))
            cornerRadius = px(ctx, 14f).toFloat()
            setStroke(px(ctx, 1.6f), col("green_mid", "#1E9462"))
        }
        val off = GradientDrawable().apply {
            setColor(col("card_bg", "#FFFFFF"))
            cornerRadius = px(ctx, 14f).toFloat()
            setStroke(px(ctx, 1f), col("input_stroke", "#D5E4D8"))
        }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_checked), on)
            addState(intArrayOf(), off)
        }
    }

    private fun progress(ctx: Context): Drawable {
        val r = px(ctx, 10f).toFloat()
        val back = GradientDrawable().apply { setColor(Color.parseColor("#E1ECE3")); cornerRadius = r }
        val front = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(col("green", "#01784B"), col("progress_end", "#6CC49A"))
        ).apply { cornerRadius = r }
        val clip = ClipDrawable(front, Gravity.LEFT, ClipDrawable.HORIZONTAL)
        return LayerDrawable(arrayOf<Drawable>(back, clip)).apply {
            setId(0, android.R.id.background)
            setId(1, android.R.id.progress)
        }
    }
}
