package com.tipaxauto

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.*
import android.graphics.drawable.GradientDrawable.Orientation

/** وضعیت ورود با کد اشتراک ۴ رقمی (کد را مدیر از پنل می‌سازد و هر کد فقط روی یک گوشی کار می‌کند). */
object Gate {
    const val PREFS = "tipax"
    const val KEY = "unlocked"

    fun isUnlocked(a: Activity) = a.getSharedPreferences(PREFS, Activity.MODE_PRIVATE).getBoolean(KEY, false)
    fun unlock(a: Activity) = a.getSharedPreferences(PREFS, Activity.MODE_PRIVATE).edit().putBoolean(KEY, true).apply()

    /** ارقام فارسی/عربی را انگلیسی می‌کند و فقط عدد نگه می‌دارد. */
    fun normalize(input: String): String = input.map {
        when (it) { in '۰'..'۹' -> '0' + (it - '۰'); in '٠'..'٩' -> '0' + (it - '٠'); else -> it }
    }.filter { it in '0'..'9' }.joinToString("")
}

class GateActivity : Activity() {

    private val GREEN = Color.parseColor("#2F7046")
    private val GREEN_DARK = Color.parseColor("#1F5A37")
    private val MUTED = Color.parseColor("#6B6B6B")
    private val RED = Color.parseColor("#C62828")

    private val font: Typeface by lazy {
        var f: Typeface? = null
        if (Build.VERSION.SDK_INT >= 26) {
            for (n in listOf("btitr", "vazirmatn")) {
                val id = resources.getIdentifier(n, "font", packageName)
                if (id != 0) { f = resources.getFont(id); break }
            }
        }
        f ?: Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()

    private fun tv(text: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        typeface = if (bold) Typeface.create(font, Typeface.BOLD) else font
        gravity = Gravity.CENTER
        setLineSpacing(0f, 1.2f)
    }

    private fun openMain() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (RemoteSwitch.isLocked(this)) {
            startActivity(Intent(this, LockedActivity::class.java)); finish(); return
        }
        RemoteSwitch.refresh(this)
        if (RemoteSwitch.hasLogin(this)) { openMain(); return }
        val oldMsg = RemoteSwitch.takeLoginMsg(this)

        window.statusBarColor = Color.parseColor("#26593C")
        window.navigationBarColor = Color.parseColor("#FBFBFB")
        if (Build.VERSION.SDK_INT >= 26) {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = window.decorView.systemUiVisibility or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = GradientDrawable(Orientation.TOP_BOTTOM, intArrayOf(Color.parseColor("#F1F6F2"), Color.parseColor("#FBFBFB")))
        }

        // ---------- بالا: سبز با گوشه‌ی گرد ----------
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            background = GradientDrawable(Orientation.TOP_BOTTOM,
                intArrayOf(Color.parseColor("#2B6A43"), Color.parseColor("#2F7046"))).apply {
                val r = dp(36).toFloat()
                cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, r, r, r, r)
            }
            setPadding(dp(24), dp(32), dp(24), dp(72))
        }
        header.addView(ImageView(this).apply {
            setImageResource(R.drawable.tipax_logo)
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = "Tipax"
        }, LinearLayout.LayoutParams(dp(160), -2))
        header.addView(ImageView(this).apply {
            setImageResource(R.drawable.ecobox)
            scaleType = ImageView.ScaleType.FIT_CENTER
            rotation = -6f
        }, LinearLayout.LayoutParams(dp(138), dp(120)).apply { topMargin = dp(26) })
        // دایره‌های تزئینی نیمه‌شفاف پشت هدر
        fun circle(sizeDp: Int, alpha: Int) = View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.argb(alpha, 255, 255, 255))
            }
        }
        val headerWrap = FrameLayout(this)
        headerWrap.addView(header, FrameLayout.LayoutParams(-1, -2))
        headerWrap.addView(circle(72, 20), FrameLayout.LayoutParams(dp(72), dp(72)).apply {
            gravity = Gravity.TOP or Gravity.RIGHT
            topMargin = -dp(19); rightMargin = dp(41)
        })
        headerWrap.addView(circle(14, 26), FrameLayout.LayoutParams(dp(14), dp(14)).apply {
            gravity = Gravity.BOTTOM or Gravity.RIGHT
            bottomMargin = dp(40); rightMargin = dp(30)
        })
        page.addView(headerWrap, LinearLayout.LayoutParams(-1, -2))

        // ---------- کارت سفید ----------
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(Color.WHITE)
                cornerRadius = dp(30).toFloat()
                setStroke(dp(1), Color.parseColor("#DCEBE2"))
            }
            elevation = dp(8).toFloat()
            setPadding(dp(22), dp(24), dp(22), dp(20))
        }
        card.addView(tv("به سامانه خوش آمدید", 13f, Color.parseColor("#4A9468")))
        card.addView(tv("ربات اتومات فایل‌های تیپاکس", 22f, GREEN_DARK, true),
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        card.addView(tv("سرعت، دقت و اطمینان در جمع‌آوری مرسوله‌ها؛\nهمراه همیشگی کوریر حرفه‌ای.", 14f, MUTED),
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        card.addView(View(this).apply { setBackgroundColor(Color.parseColor("#E6EFE9")) },
            LinearLayout.LayoutParams(-1, dp(1)).apply { topMargin = dp(18) })
        card.addView(tv("کد اشتراک", 14f, GREEN_DARK, true).apply { gravity = Gravity.START },
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(18) })
        card.addView(tv("کد ۴ رقمی که مدیر سازمان در اختیار شما قرار داده است", 12.5f, MUTED).apply { gravity = Gravity.START },
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(2) })

        val inputBg = GradientDrawable().apply {
            setColor(Color.parseColor("#F7F8F7"))
            cornerRadius = dp(22).toFloat()
            setStroke(dp(1), Color.parseColor("#D5E3DA"))
        }
        val pass = EditText(this).apply {
            setTextColor(Color.parseColor("#17281C"))
            typeface = font
            textSize = 28f
            letterSpacing = 0.35f
            gravity = Gravity.CENTER
            inputType = InputType.TYPE_CLASS_NUMBER
            filters = arrayOf(android.text.InputFilter.LengthFilter(4))
            imeOptions = EditorInfo.IME_ACTION_DONE
            maxLines = 1
            textDirection = View.TEXT_DIRECTION_LTR
            background = inputBg
            setPadding(dp(16), dp(10), dp(16), dp(10))
            setOnFocusChangeListener { _, f ->
                inputBg.setStroke(dp(if (f) 2 else 1), Color.parseColor(if (f) "#2F7046" else "#D5E3DA"))
                inputBg.setColor(if (f) Color.WHITE else Color.parseColor("#F7F8F7"))
            }
        }
        card.addView(pass, LinearLayout.LayoutParams(-1, dp(62)).apply { topMargin = dp(12) })

        val err = tv(oldMsg.ifEmpty { "کد اشتباه است" }, 14f, RED).apply { visibility = if (oldMsg.isEmpty()) View.GONE else View.VISIBLE }
        card.addView(err, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })

        val btn = Button(this).apply {
            text = "ورود به سامانه"
            isAllCaps = false
            stateListAnimator = null
            typeface = Typeface.create(font, Typeface.BOLD)
            textSize = 18f
            setTextColor(Color.WHITE)
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(GREEN, Color.parseColor("#4A9468"))
            ).apply { cornerRadius = dp(20).toFloat() }
        }
        card.addView(btn, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(20) })
        card.addView(tv("هر کد اشتراک فقط روی یک دستگاه فعال می‌شود.\nاین مرحله تنها یک‌بار انجام می‌شود.", 12.5f, MUTED),
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })

        page.addView(card, LinearLayout.LayoutParams(-1, -2).apply {
            marginStart = dp(20); marginEnd = dp(20); topMargin = -dp(36)
        })
        page.addView(View(this), LinearLayout.LayoutParams(-1, 0, 0.6f))

        // سه ویژگی سازمان
        val features = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER
        }
        for (t in listOf("✓  سرعت", "✓  دقت", "✓  اطمینان")) {
            features.addView(tv(t, 13f, GREEN_DARK, true).apply {
                setPadding(dp(14), dp(8), dp(14), dp(8))
                background = GradientDrawable().apply {
                    setColor(Color.parseColor("#E4F0E8"))
                    cornerRadius = dp(20).toFloat()
                }
            }, LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(5); marginEnd = dp(5) })
        }
        page.addView(features, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(22) })

        page.addView(View(this), LinearLayout.LayoutParams(-1, 0, 1f))

        // پاورقی (نگه داشتن طولانی = ورود مدیر)
        val footer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setOnLongClickListener { startActivity(Intent(this@GateActivity, AdminActivity::class.java)); true }
        }
        footer.addView(tv("نسخه اختصاصی سازمانی", 12.5f, MUTED))
        footer.addView(tv("Sobhan Sedighi  •  v2", 12f, Color.parseColor("#9A9A9A")).apply {
            textDirection = View.TEXT_DIRECTION_LTR
        }, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(2) })
        page.addView(footer, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16); bottomMargin = dp(20) })

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            addView(page)
            background = GradientDrawable(Orientation.TOP_BOTTOM, intArrayOf(Color.parseColor("#F1F6F2"), Color.parseColor("#FBFBFB")))
        }
        setContentView(scroll)

        // بالای صفحه زیر نوار وضعیت نرود
        scroll.setOnApplyWindowInsetsListener { _, ins ->
            header.setPadding(dp(24), dp(32) + ins.systemWindowInsetTop, dp(24), dp(72))
            ins
        }

        fun shake(v: View) {
            android.animation.ObjectAnimator.ofFloat(v, "translationX", 0f, -dp(10).toFloat(), dp(10).toFloat(), -dp(6).toFloat(), dp(6).toFloat(), 0f)
                .apply { duration = 350; start() }
        }

        var checking = false
        fun submit() {
            if (checking) return
            val code = Gate.normalize(pass.text.toString())
            fun bad(text: String) {
                err.text = text
                err.visibility = View.VISIBLE
                pass.setText("")
                shake(pass)
            }
            if (code.length != 4) { bad("کد باید ۴ رقم باشد"); return }
            checking = true
            btn.isEnabled = false
            err.text = "در حال بررسی…"
            err.setTextColor(MUTED)
            err.visibility = View.VISIBLE
            RemoteSwitch.activate(this, code) { r ->
                checking = false
                btn.isEnabled = true
                err.setTextColor(RED)
                when (r) {
                    "ok" -> {
                        Gate.unlock(this)
                        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                            .hideSoftInputFromWindow(pass.windowToken, 0)
                        RemoteSwitch.refresh(this)
                        openMain()
                    }
                    "invalid" -> bad("کد اشتباه است")
                    "used" -> bad("این کد روی گوشی دیگری فعال شده است")
                    "banned" -> bad("این کد مسدود شده است")
                    "expired" -> bad("اشتراک این کد تمام شده است")
                    "locked" -> bad("تلاش اشتباه زیاد بود. ۱۵ دقیقه بعد دوباره امتحان کن")
                    else -> { err.text = "اتصال به اینترنت برقرار نشد"; err.visibility = View.VISIBLE }
                }
            }
        }
        btn.setOnClickListener { submit() }
        pass.setOnEditorActionListener { _, id, _ -> if (id == EditorInfo.IME_ACTION_DONE) { submit(); true } else false }
    }
}
