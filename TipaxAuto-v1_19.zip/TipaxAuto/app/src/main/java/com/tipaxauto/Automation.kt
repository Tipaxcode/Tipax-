package com.tipaxauto

import android.content.Context

/** وضعیت مشترک بین صفحه اصلی و سرویس (همه روی main thread). */
object Automation {
    var codes: List<String> = emptyList()
    var fileKey: String = ""
    var index = 0
    /** شماره‌ی (۱‑مبنا) آخرین بارکدی که باید زده شود؛ ۰ = تا آخر فایل. */
    var endNumber = 0
    /** اتومیشن وقتی index به این عدد برسد تمام می‌شود (بدون خودش). */
    val limit: Int get() = if (endNumber in 1 until codes.size) endNumber else codes.size
    var delayMs = 2000L
    var submitMode = 0          // 0 خودکار، 1 فقط دکمه SEARCH، 2 فقط Enter
    var remoteDelayMs: Long? = null   // اگر مدیر تعیین کرده باشد، جای تنظیم گوشی را می‌گیرد
    var remoteMode: Int? = null
    var backEvery = 0                 // هر چند بارکد یک بار: برگشت به منو و ورود دوباره (۰ = خاموش)
    var remoteBackEvery: Int? = null
    val effBackEvery: Int get() = remoteBackEvery ?: backEvery
    val effDelayMs: Long get() = remoteDelayMs ?: delayMs
    val effMode: Int get() = remoteMode ?: submitMode
    var username = ""
    var password = ""
    var running = false
    /** بارکدهایی که علامت تأیید نگرفتند (برای اینکه کسری بی‌صدا نماند). */
    val missed = mutableListOf<String>()
    var statusText = "آماده"
    var listener: (() -> Unit)? = null

    fun setStatus(s: String) {
        statusText = s
        listener?.invoke()
    }

    fun save(ctx: Context) {
        if (fileKey.isEmpty()) return
        ctx.getSharedPreferences("tipax", Context.MODE_PRIVATE)
            .edit().putInt("pos_$fileKey", index).apply()
    }
}
