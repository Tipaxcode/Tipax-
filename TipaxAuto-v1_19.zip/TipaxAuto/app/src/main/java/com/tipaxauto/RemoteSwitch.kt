package com.tipaxauto

import android.content.Context
import android.os.Handler
import android.os.Build
import android.os.Looper
import android.provider.Settings
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID
import kotlin.concurrent.thread

/**
 * کلید روشن/خاموش + تنظیمات راه‌دور (همان جدول Supabase که صفحه‌ی tipax-switch.html عوضش می‌کند).
 * اگر مدیر «خاموش» کند، برنامه قفل می‌شود. تنظیمات (رنگ، متن، تأخیر، روش ثبت) هم از همین جدول می‌آید.
 * اگر اینترنت قطع باشد، آخرین وضعیت و تنظیمات شناخته‌شده می‌ماند.
 */
object RemoteSwitch {
    // فقط کلید «publishable» (عمومی) اینجاست؛ هرگز کلید secret / service_role را نگذار.
    const val SB_URL = "https://outhyhmxtjiqpswtnrkb.supabase.co"
    const val SB_KEY = "sb_publishable_BjekGXngklIbglIPSG3h2g_hLDctNd4"

    const val CHECK_EVERY_MS = 5_000L
    private const val KEY_LOCKED = "remote_locked"
    private val main = Handler(Looper.getMainLooper())

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(Gate.PREFS, Context.MODE_PRIVATE)

    private const val KEY_BANNED = "remote_banned"
    private const val KEY_EXPIRED = "remote_expired"
    private const val KEY_CODE = "sub_code"
    private const val KEY_MSG = "login_msg"
    private const val KEY_DEVID = "device_id"
    private const val KEY_SUB = "sub_state"      // "" نامشخص | "unlimited" | زمان پایان (میلی‌ثانیه)

    /** مدیر این کاربر را بن کرده؟ */
    fun isBanned(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_BANNED, false)

    /** قفل کلی (کلید خاموش) یا بن شدن همین کاربر؛ هر دو برنامه را قفل می‌کنند. */
    /** مدت اشتراک این کد تمام شده؟ */
    fun isExpired(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_EXPIRED, false)

    fun isLocked(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_LOCKED, false) || isBanned(ctx) || isExpired(ctx)

    /** زمان پایان اشتراک (میلی‌ثانیه)؛ null = نامحدود یا نامشخص. */
    fun subEndMs(ctx: Context): Long? = prefs(ctx).getString(KEY_SUB, "")?.toLongOrNull()

    /** «نامحدود» / «۲۳ روز» / «۵ ساعت» / «تمام شده»؛ اگر هنوز چیزی نمی‌دانیم null. */
    fun subText(ctx: Context): String? {
        val raw = prefs(ctx).getString(KEY_SUB, "") ?: ""
        if (raw == "unlimited") return "نامحدود"
        val end = raw.toLongOrNull() ?: return null
        val left = end - System.currentTimeMillis()
        if (left <= 0) return "تمام شده"
        val min = left / 60_000
        val txt = when {
            min >= 2 * 24 * 60 -> "${(min + 24 * 60 - 1) / (24 * 60)} روز"
            min >= 60 -> "${(min + 59) / 60} ساعت"
            else -> "${maxOf(1, min)} دقیقه"
        }
        return txt.map { if (it in '0'..'9') '۰' + (it - '0') else it }.joinToString("")
    }

    /** آیا اشتراک کمتر از ۳ روز مانده؟ (برای رنگ هشدار) */
    fun subSoon(ctx: Context): Boolean {
        val end = subEndMs(ctx) ?: return false
        return end - System.currentTimeMillis() in 1..(3L * 24 * 3600 * 1000)
    }

    fun code(ctx: Context): String = prefs(ctx).getString(KEY_CODE, "") ?: ""
    fun saveCode(ctx: Context, code: String) { prefs(ctx).edit().putString(KEY_CODE, code.trim()).apply() }

    /** با کد اشتراک وارد شده؟ */
    fun hasLogin(ctx: Context): Boolean = prefs(ctx).getBoolean(Gate.KEY, false) && code(ctx).isNotBlank()

    /** پیامی که بعد از باطل شدن کد، یک‌بار در صفحه‌ی ورود نشان داده می‌شود. */
    fun takeLoginMsg(ctx: Context): String {
        val m = prefs(ctx).getString(KEY_MSG, "") ?: ""
        if (m.isNotEmpty()) prefs(ctx).edit().remove(KEY_MSG).apply()
        return m
    }

    private fun logout(ctx: Context, msg: String) {
        prefs(ctx).edit().remove(KEY_CODE).putBoolean(Gate.KEY, false).putBoolean(KEY_BANNED, false).putBoolean(KEY_EXPIRED, false).putString(KEY_MSG, msg).putString(KEY_SUB, "").apply()
    }

    private fun post(fn: String, body: JSONObject): String? = try {
        val c = URL("$SB_URL/rest/v1/rpc/$fn").openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 8000
        c.readTimeout = 8000
        c.doOutput = true
        c.setRequestProperty("apikey", SB_KEY)
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("Accept", "application/json")
        c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val res = if (c.responseCode == 200) c.inputStream.bufferedReader().use { it.readText() }.trim().trim('"') else null
        c.disconnect()
        res
    } catch (_: Exception) { null }

    private fun deviceBody(ctx: Context, code: String) = JSONObject()
        .put("p_code", code)
        .put("p_id", deviceId(ctx))
        .put("p_model", (Build.MANUFACTURER + " " + Build.MODEL).take(60))
        .put("p_ver", appVersion(ctx))

    /** ورود با کد اشتراک. نتیجه روی main thread: ok | invalid | used | banned | expired | locked | null (اینترنت نیست) */
    fun activate(ctx: Context, code: String, done: (String?) -> Unit) {
        val app = ctx.applicationContext
        thread(name = "activate") {
            val r = post("tipax_activate", deviceBody(app, code))
            main.post {
                if (r == "ok") {
                    prefs(app).edit().putBoolean(KEY_BANNED, false).putBoolean(KEY_EXPIRED, false).apply()
                    saveCode(app, code)
                }
                done(r)
            }
        }
    }

    /** شناسه‌ی ثابت دستگاه (با پاک کردن اطلاعات برنامه هم عوض نمی‌شود). */
    fun deviceId(ctx: Context): String {
        val p = prefs(ctx)
        p.getString(KEY_DEVID, null)?.let { if (it.isNotBlank()) return it }
        val aid = try { Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ANDROID_ID) } catch (_: Exception) { null }
        val id: String = if (aid == null || aid.isBlank() || aid == "9774d56d682e549c") UUID.randomUUID().toString() else aid
        p.edit().putString(KEY_DEVID, id).apply()
        return id
    }

    private fun appVersion(ctx: Context): String = try {
        ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: ""
    } catch (_: Exception) { "" }

    /** زمان باقی‌مانده‌ی اشتراک را می‌گیرد (اگر تابعش در Supabase ساخته نشده باشد، چیزی عوض نمی‌شود). */
    private fun syncSub(ctx: Context, saved: String) {
        val body = JSONObject().put("p_code", saved).put("p_id", deviceId(ctx))
        when (val r = post("tipax_sub_info", body)) {
            null, "none", "" -> {}
            "unlimited" -> prefs(ctx).edit().putString(KEY_SUB, "unlimited").apply()
            else -> r.toLongOrNull()?.let {
                prefs(ctx).edit().putString(KEY_SUB, (System.currentTimeMillis() + it * 1000).toString()).apply()
            }
        }
    }

    /** هر چند ثانیه: هنوز کدم معتبر است؟ بن نشده‌ام؟ (جواب نگرفت = وضعیت قبلی می‌ماند) */
    private fun ping(ctx: Context) {
        val saved = code(ctx)
        if (saved.isBlank()) return
        when (post("tipax_ping", deviceBody(ctx, saved))) {
            "ok" -> { prefs(ctx).edit().putBoolean(KEY_BANNED, false).putBoolean(KEY_EXPIRED, false).apply(); syncSub(ctx, saved) }
            "banned" -> prefs(ctx).edit().putBoolean(KEY_BANNED, true).putBoolean(KEY_EXPIRED, false).apply()
            "expired" -> { prefs(ctx).edit().putBoolean(KEY_EXPIRED, true).putBoolean(KEY_BANNED, false).apply(); syncSub(ctx, saved) }
            "invalid" -> logout(ctx, "این کد اشتراک دیگر معتبر نیست. کد جدید را وارد کن.")
            "used" -> logout(ctx, "این کد روی گوشی دیگری فعال شده است. کد جدید را وارد کن.")
        }
    }

    /** تأخیر و روش ثبتِ اجباری را از تنظیمات راه‌دور به Automation می‌دهد (روی main thread صدا بزن). */
    fun applyRuntime() {
        Automation.remoteDelayMs = Skin.delaySec?.let { (it.coerceAtLeast(0.5) * 1000).toLong() }
        Automation.remoteMode = Skin.mode
        Automation.remoteBackEvery = Skin.backEvery
    }

    private fun open(select: String): HttpURLConnection {
        val c = URL("$SB_URL/rest/v1/tipax_app_status?id=eq.1&select=$select").openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        c.setRequestProperty("apikey", SB_KEY)
        c.setRequestProperty("Accept", "application/json")
        c.useCaches = false
        return c
    }

    /** وضعیت را از اینترنت می‌گیرد؛ نتیجه (قفل است؟) روی main thread به done داده می‌شود. */
    fun refresh(ctx: Context, done: ((locked: Boolean) -> Unit)? = null) {
        val app = ctx.applicationContext
        thread(name = "remote-switch") {
            try {
                var c = open("active,config")
                if (c.responseCode == 400) {   // ستون config هنوز در Supabase ساخته نشده
                    c.disconnect()
                    c = open("active")
                }
                if (c.responseCode == 200) {
                    val rows = JSONArray(c.inputStream.bufferedReader().use { it.readText() })
                    if (rows.length() > 0) {
                        val row = rows.getJSONObject(0)
                        val active = row.optBoolean("active", true)
                        prefs(app).edit().putBoolean(KEY_LOCKED, !active).apply()
                        if (row.has("config")) {
                            Skin.save(app, (row.optJSONObject("config") ?: JSONObject()).toString())
                        }
                    }
                }
                c.disconnect()
            } catch (_: Exception) {
                // اینترنت یا سرور در دسترس نیست؛ وضعیت قبلی می‌ماند
            }
            // بررسی کد اشتراک و بن (اگر اینترنت نباشد چیزی عوض نمی‌شود)
            ping(app)
            main.post {
                applyRuntime()
                done?.invoke(isLocked(app))
            }
        }
    }
}
