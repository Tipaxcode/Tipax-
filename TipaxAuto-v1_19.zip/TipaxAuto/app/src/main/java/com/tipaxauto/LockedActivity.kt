package com.tipaxauto

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/** صفحه‌ی «برنامه توسط مدیر غیرفعال شده است». هر ۱۵ ثانیه خودش دوباره بررسی می‌کند. */
class LockedActivity : Activity() {

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var status: TextView
    private val poll = object : Runnable {
        override fun run() { check(false); ui.postDelayed(this, 15_000) }
    }

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()

    private fun tv(text: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        typeface = face(bold)
        gravity = Gravity.CENTER
        includeFontPadding = true
        letterSpacing = 0f
        textDirection = View.TEXT_DIRECTION_RTL
        setLineSpacing(0f, 1.3f)
    }

    // فونت: اول res/font (btitr یا vazirmatn)، بعد assets/fonts، آخر هم فونت سیستم
    private val baseFont: Typeface by lazy {
        var f: Typeface? = null
        if (Build.VERSION.SDK_INT >= 26) {
            for (n in listOf("btitr", "vazirmatn")) {
                val id = resources.getIdentifier(n, "font", packageName)
                if (id != 0) try { f = resources.getFont(id); break } catch (_: Exception) {}
            }
        }
        if (f == null) {
            for (n in listOf("btitr.ttf", "vazirmatn.ttf", "Vazirmatn.ttf")) {
                try { f = Typeface.createFromAsset(assets, "fonts/$n"); break } catch (_: Exception) {}
            }
        }
        f ?: Typeface.create("sans-serif", Typeface.NORMAL)
    }

    private fun face(bold: Boolean = false): Typeface =
        if (bold) Typeface.create(baseFont, Typeface.BOLD) else baseFont

    private fun darken(c: Int, f: Float) =
        Color.rgb((Color.red(c) * f).toInt(), (Color.green(c) * f).toInt(), (Color.blue(c) * f).toInt())

    private fun circle(color: Int, stroke: Int = 0, strokeW: Int = 0) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(color)
        if (stroke != 0) setStroke(strokeW, stroke)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Skin.load(this)
        // رنگ‌ها از تم برنامه (قابل تغییر از پنل: header_start / header_end / green)
        val cDark = Skin.col("header_start", "#00573A")
        val cMain = Skin.col("header_end", "#01784B")
        val cBtn = Skin.col("green", "#01784B")
        val cDeep = darken(cDark, 0.62f)
        window.statusBarColor = cDeep
        window.navigationBarColor = cMain

        val banned = RemoteSwitch.isBanned(this)
        val expired = RemoteSwitch.isExpired(this)
        val title = if (banned) "دسترسی شما مسدود شده است"
            else if (expired) "اشتراک شما تمام شد"
            else Skin.text("lock_title", "برنامه غیرفعال است")
        var message = if (banned) "دسترسی این دستگاه به برنامه توسط مدیر قطع شده است.\nبرای فعال شدن دوباره با مدیر تماس بگیر."
            else if (expired) "مدت اشتراک شما به پایان رسیده است.\nبرای تمدید و ادامه‌ی کار، با مدیر تماس بگیرید."
            else Skin.text("lock_message", "استفاده از این برنامه فعلاً توسط مدیر متوقف شده است.\nبرای فعال شدن دوباره با مدیر تماس بگیرید.")
        // اگر پیام همان عنوان تکراری بود، نشانش نده
        if (message.trim() == title.trim()) message = "برای فعال شدن دوباره با مدیر تماس بگیرید."

        val root = android.widget.FrameLayout(this).apply {
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(cDeep, cDark, cMain)
            )
        }
        // حلقه‌های محو پس‌زمینه
        root.addView(View(this).apply { background = circle(Color.parseColor("#14FFFFFF")) },
            android.widget.FrameLayout.LayoutParams(dp(320), dp(320), Gravity.TOP or Gravity.END).apply { topMargin = dp(-120); marginEnd = dp(-110) })
        root.addView(View(this).apply { background = circle(Color.parseColor("#0FFFFFFF")) },
            android.widget.FrameLayout.LayoutParams(dp(260), dp(260), Gravity.BOTTOM or Gravity.START).apply { bottomMargin = dp(-90); marginStart = dp(-100) })

        root.addView(View(this).apply { background = circle(Color.parseColor("#0AFFFFFF")) },
            android.widget.FrameLayout.LayoutParams(dp(160), dp(160), Gravity.CENTER_VERTICAL or Gravity.START).apply { marginStart = dp(-70) })

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(24), dp(24), dp(24))
        }
        root.addView(col, android.widget.FrameLayout.LayoutParams(-1, -1).apply { gravity = Gravity.CENTER })

        // فضای بالا
        col.addView(View(this), LinearLayout.LayoutParams(0, 0, 1f))

        // آیکون قفل با هاله‌ی نبض‌دار
        val iconBox = android.widget.FrameLayout(this)
        val halo = View(this).apply { background = circle(Color.parseColor("#22FFFFFF")) }
        val ring = View(this).apply { background = circle(Color.TRANSPARENT, Color.parseColor("#55FFFFFF"), dp(2)) }
        val disc = android.widget.ImageView(this).apply {
            setImageResource(if (banned) R.drawable.ic_ban_big else if (expired) R.drawable.ic_clock_big else R.drawable.ic_lock_big)
            setPadding(dp(30), dp(30), dp(30), dp(30))
            background = circle(Color.parseColor("#33FFFFFF"), Color.parseColor("#88FFFFFF"), dp(2))
            elevation = dp(8).toFloat()
        }
        iconBox.addView(halo, android.widget.FrameLayout.LayoutParams(dp(170), dp(170), Gravity.CENTER))
        iconBox.addView(ring, android.widget.FrameLayout.LayoutParams(dp(138), dp(138), Gravity.CENTER))
        iconBox.addView(disc, android.widget.FrameLayout.LayoutParams(dp(104), dp(104), Gravity.CENTER))
        try {
            android.animation.ObjectAnimator.ofPropertyValuesHolder(
                halo,
                android.animation.PropertyValuesHolder.ofFloat(View.SCALE_X, 0.85f, 1.1f),
                android.animation.PropertyValuesHolder.ofFloat(View.SCALE_Y, 0.85f, 1.1f),
                android.animation.PropertyValuesHolder.ofFloat(View.ALPHA, 1f, 0.35f)
            ).apply {
                duration = 1800
                repeatCount = android.animation.ValueAnimator.INFINITE
                repeatMode = android.animation.ValueAnimator.REVERSE
                start()
            }
        } catch (_: Exception) {}
        col.addView(iconBox, LinearLayout.LayoutParams(dp(170), dp(170)))

        // کارت شیشه‌ای متن
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(26), dp(24), dp(26))
            elevation = dp(10).toFloat()
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.parseColor("#33FFFFFF"), Color.parseColor("#14FFFFFF"))
            ).apply {
                cornerRadius = dp(30).toFloat()
                setStroke(dp(1), Color.parseColor("#44FFFFFF"))
            }
        }
        val chipText = if (banned) "مسدود" else if (expired) "پایان اشتراک" else "غیرفعال"
        card.addView(tv(chipText, 11.5f, Color.WHITE, true).apply {
            setPadding(dp(14), dp(4), dp(14), dp(4))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#33FFFFFF")); cornerRadius = dp(14).toFloat()
                setStroke(dp(1), Color.parseColor("#55FFFFFF"))
            }
        }, LinearLayout.LayoutParams(-2, -2).apply { bottomMargin = dp(12) })
        card.addView(tv(title, 23f, Color.WHITE, true))
        card.addView(View(this).apply { background = GradientDrawable().apply { setColor(Color.parseColor("#66FFFFFF")); cornerRadius = dp(2).toFloat() } },
            LinearLayout.LayoutParams(dp(40), dp(3)).apply { topMargin = dp(12); bottomMargin = dp(12) })
        card.addView(tv(message, 14.5f, Color.parseColor("#E8F5EE")).apply { setLineSpacing(0f, 1.55f) })
        if (expired) {
            val end = RemoteSwitch.subEndMs(this)
            if (end != null) {
                val days = ((System.currentTimeMillis() - end) / 86_400_000L).toInt()
                val ago = if (days <= 0) "امروز تمام شد" else "$days روز پیش تمام شد"
                card.addView(tv(ago.map { if (it in '0'..'9') '۰' + (it - '0') else it }.joinToString(""),
                    12.5f, Color.parseColor("#CDEBDA")),
                    LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(12) })
            }
        }
        col.addView(card, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(26) })

        // وضعیت بررسی
        status = tv(" ", 13f, Color.parseColor("#CDEBDA"))
        col.addView(status, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })

        val btn = Button(this).apply {
            text = if (expired) "تمدید کردم؛ بررسی" else "بررسی دوباره"
            isAllCaps = false
            stateListAnimator = null
            textSize = 16f
            setTextColor(cBtn)
            typeface = face(true)
            elevation = dp(6).toFloat()
            background = android.graphics.drawable.RippleDrawable(
                android.content.res.ColorStateList.valueOf((cBtn and 0x00FFFFFF) or 0x33000000),
                GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = dp(28).toFloat() }, null)
            setOnClickListener { check(true) }
        }
        col.addView(btn, LinearLayout.LayoutParams(-1, dp(56)).apply { topMargin = dp(10) })

        col.addView(View(this), LinearLayout.LayoutParams(0, 0, 1f))
        col.addView(tv(Skin.text("header_name", "Sobhan Sedighi"), 11f, Color.parseColor("#99FFFFFF")))

        setContentView(root)
    }

    override fun onResume() { super.onResume(); ui.post(poll) }
    override fun onPause() { super.onPause(); ui.removeCallbacks(poll) }

    private fun check(manual: Boolean) {
        if (manual) status.text = "در حال بررسی…"
        RemoteSwitch.refresh(this) { locked ->
            if (!locked) {
                startActivity(Intent(this, GateActivity::class.java))
                finish()
            } else if (manual) {
                status.text = "هنوز غیرفعال است."
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { finishAffinity() }
}
