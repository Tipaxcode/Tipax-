package com.tipaxauto

import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import kotlin.concurrent.thread

/**
 * تقسیم کار بین چند گوشی: هر گوشی که «همین فایل» را انتخاب کند، با اثر انگشت فایل
 * (هش بارکدها) در Supabase ثبت می‌شود. گوشی‌های هم‌فایل همدیگر را می‌بینند و بارکدها
 * بین‌شان مساوی تقسیم می‌شود (۵۰۰ بارکد روی ۲ گوشی: ۱..۲۵۰ و ۲۵۱..۵۰۰).
 * وقتی اتومیشن در حال اجراست سهم عوض نمی‌شود (قفل می‌ماند).
 */
object SplitSync {
    class Slice(val count: Int, val pos: Int, val start: Int, val end: Int) {
        val size: Int get() = end - start + 1
    }

    private const val EVERY_MS = 4_000L
    private val main = Handler(Looper.getMainLooper())

    @Volatile private var gen = 0
    private var room = ""

    /** آخرین سهم محاسبه‌شده (۱‑مبنا، شامل دو سر)؛ null = هنوز جواب نگرفته. */
    var slice: Slice? = null
        private set
    var offline = false
        private set
    var onChange: (() -> Unit)? = null

    fun roomKey(codes: List<String>): String {
        val md = MessageDigest.getInstance("SHA-256")
        for (c in codes) { md.update(c.toByteArray(Charsets.UTF_8)); md.update(','.code.toByte()) }
        return md.digest().joinToString("") { "%02x".format(it) }.take(32)
    }

    /** سهم گوشی شماره‌ی pos (از ۰) از n بارکد بین count گوشی؛ باقیمانده به گوشی‌های اول می‌رسد. */
    fun compute(n: Int, count: Int, pos: Int): Slice {
        val base = n / count
        val rem = n % count
        val start = pos * base + minOf(pos, rem) + 1
        val size = base + if (pos < rem) 1 else 0
        return Slice(count, pos, start, start + size - 1)
    }

    private fun call(fn: String, body: JSONObject): String? = try {
        val c = URL("${RemoteSwitch.SB_URL}/rest/v1/rpc/$fn").openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 8000
        c.readTimeout = 8000
        c.doOutput = true
        c.setRequestProperty("apikey", RemoteSwitch.SB_KEY)
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("Accept", "application/json")
        c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val res = if (c.responseCode in 200..299) c.inputStream.bufferedReader().use { it.readText() }.trim() else null
        c.disconnect()
        res
    } catch (_: Exception) { null }

    /** شروع جستجو و ضربان برای این فایل (اگر همین فایل از قبل در حال جستجوست، کاری نمی‌کند). */
    fun begin(ctx: Context, codes: List<String>) {
        if (codes.isEmpty()) return
        val app = ctx.applicationContext
        val r = roomKey(codes)
        if (r == room && running) return
        stopInternal(app, leave = true)
        room = r
        running = true
        val my = ++gen
        val dev = RemoteSwitch.deviceId(app)
        val model = (Build.MANUFACTURER + " " + Build.MODEL).take(60)
        val n = codes.size
        thread(name = "split-sync") {
            while (gen == my) {
                val res = call("tipax_split_join", JSONObject().put("p_room", r).put("p_dev", dev).put("p_model", model))
                var found: Slice? = null
                var off = false
                if (res == null) off = true
                else try {
                    val arr = JSONArray(res)
                    var pos = -1
                    for (i in 0 until arr.length()) if (arr.getJSONObject(i).optString("dev") == dev) pos = i
                    if (pos >= 0 && arr.length() > 0) found = compute(n, arr.length(), pos)
                } catch (_: Exception) { off = true }
                main.post {
                    if (gen != my) return@post
                    offline = off
                    // وقتی اتومیشن در حال اجراست سهم قفل است و عوض نمی‌شود
                    if (found != null && !Automation.running) slice = found
                    onChange?.invoke()
                }
                try { Thread.sleep(EVERY_MS) } catch (_: InterruptedException) { }
            }
        }
    }

    private var running = false

    private fun stopInternal(app: Context, leave: Boolean) {
        val oldRoom = room
        gen++
        running = false
        slice = null
        offline = false
        room = ""
        if (leave && oldRoom.isNotEmpty()) {
            val dev = RemoteSwitch.deviceId(app)
            thread(name = "split-leave") { call("tipax_split_leave", JSONObject().put("p_room", oldRoom).put("p_dev", dev)) }
        }
    }

    /** خروج از گروه (خاموش کردن تقسیم کار یا حذف فایل). */
    fun stop(ctx: Context) = stopInternal(ctx.applicationContext, leave = true)
}
